#include "misLine.h"
#include <string>
#include <iostream>
#include <math.h>
using namespace std ;
misLine::misLine(void)
  {
  p1.x=0.0;
  p1.y=0.0;
  p1.z=0.0;
  p2.x=0.0;
  p2.y=0.0;
  p2.z=0.0;
  angleZX=0;
  angleYZ=0;
  angleXY=0;
  }
misLine::misLine(misPoint ip1, misPoint ip2)
  {
  p1=ip1;
  p2=ip2;
  calculate();
  }
misLine::~misLine(void)
  {
  }
void misLine::setP1(double px,double py,double pz)
  {
  p1.x=px;
  p1.y=py;
  p1.z=pz;
  calculate();
  }
void misLine::setP2(double px,double py,double pz)
  {
  p2.x=px;
  p2.y=py;
  p2.z=pz;
  calculate();
  }
void misLine::setP1(misPoint p)
  {
  p1=p;
  calculate();
  }
void misLine::setP2(misPoint p)
  {
  p2=p;
  calculate();
  }
//calculate the vector representing this line
//p1 represents the arrow end of the segment.
//p2 is the tail end.
void misLine::calculate(void)
  {
  
  dirVector.x=p2.x-p1.x;
  dirVector.y=p2.y-p1.y;
  dirVector.z=p2.z-p1.z;
  //normalize.
  double mag=dirVector.magnitude();
  if (mag != 0.0){
    dirVector.x/=mag;
    dirVector.y/=mag;
    dirVector.z/=mag;
    }        
  else{ 
    dirVector.x=0.0;
    dirVector.y=0.0;
    dirVector.z=0.0;
    }

  //either z or x axis is the reference vector
  misPoint zAxis(0.0,0.0,1.0);
  misPoint xAxis(1.0,0.0,0.0);

  // For non-unit vectors:
  // (1) normalize each vector (NOTE: otherwise devide the dot product by the product of the magnitudes of the vectors) 
  // (2) compute the dot product
  // (3) take the arc cos to get the angle. 
  // (4) calculate sign of the angle

  //CALCULATE XY plane angle to X (angleXY)
  misPoint xyVector=getDirVector();
  xyVector.z=0;
  xyVector=xyVector.normalize();

  //dot product of the x axis vector and the line normalized direction vector with no z component.
  angleXY= arc_cosine(xAxis.dotProduct(xyVector));

  //need to give the angle a sign:
  //if it is on the negative y side then the angle is negative 
  if (xyVector.y<0)
  angleXY*=-1;

  //same works for the other planes
  //CALCULATE ZX plane angle to Z  (angleZX)

  misPoint zxVector;
  zxVector=getDirVector();
  zxVector.y=0.0;
  ///needs to be normalized and save...otherwise the doproduct has to be devided by the product of 
  // vector magnitudes
  zxVector=zxVector.normalize();

  //dot product of the z axis vector and the line normalized direction vector with no y component.
  angleZX= arc_cosine(zAxis.dotProduct(zxVector));
  //need to give the angle a sign:
  //if it is on the negative x side then the angle is negative 
  if (zxVector.x<0)
  angleZX*=-1;

  //CALCULATE YZ plane angle to Z (angleYZ)
  misPoint yzVector=getDirVector();
  yzVector.x=0.0;
  yzVector=yzVector.normalize();
  //dot product of the z axis vector and the line normalized direction vector with no y component.
  angleYZ= arc_cosine(zAxis.dotProduct(yzVector));
  //need to give the angle a sign:
  //if it is on the negative y side then the angle is negative 
  if (yzVector.y<0)
  angleYZ*=-1;
  //cout<<" LINE ANGLES: "<<"XY : "<<angleXY<<" ZX : "<<angleZX<<" YZ : "<<angleYZ<<endl; 

  midPoint.x=(p1.x+p2.x)/2;
  midPoint.y=(p1.y+p2.y)/2;
  midPoint.z=(p1.z+p2.z)/2;

}

void misLine::draw(double radius){

  p1.setColor(color[0],color[1],color[2],color[3]);
  p2.setColor(color[0],color[1],color[2],color[3]);

  p1.draw(radius);
  p2.draw(radius);

  glPushMatrix();
  //glColor4f(color[0],color[1],color[2], color[3]);   //this is called by draw cylinder.
  misMatrix(p1,p2).glMultiply();
  drawCylinder(radius,p1.distance(p2));
  glTranslatef(0.0f, 0.0f,p1.distance(p2));
  drawSphere(radius);

  glPopMatrix();
  }
void misLine::drawLabel(string label){
  string s=string("  ")+label + string(":P1: "+ convToString(p1.x)+", "+ convToString(p1.y)+", "+ convToString(p1.z));
  drawText3D(p1.x,p1.y,p1.z, s);
  s=string("  ")+label + string(":P2: "+ convToString(p2.x)+", "+ convToString(p2.y)+", "+ convToString(p2.z));
  drawText3D(p2.x,p2.y,p2.z, s); 
  }

void misLine::drawAnglesLabel(string label){
  string s=string("  ")+label + string(" XY: "+ convToString(angleXY)+" ZX: "+ convToString(angleZX)+" YZ: "+ convToString(angleYZ));
  drawText3D(midPoint.x,midPoint.y,midPoint.z, s);

  }

///distance between p1s from both lines
double misLine::distanceP1(misLine l2){
  return p1.distance(l2.getP1());
  }
///distance between p2s from both lines
double misLine::distanceP2(misLine l2){
  return p2.distance(l2.getP2());
  }

double misLine::getAngle(misLine l2){

  // For non-unit vectors:
  // (1) normalize each vector,
  // (2) compute the dot product
  // (3) take the arc cos to get the angle.

  return arc_cosine(this->getDirVector().dotProduct(l2.getDirVector()));

  //double pnorm = this->length();
  //double qnorm = l2.length();
  //double pdotq =    ( p2.x - p1.x ) * ( l2.p2.x - l2.p1.x ) 
  //         + ( p2.y - p1.y ) * ( l2.p2.y - l2.p1.y ) 
  //         + ( p2.z - p1.z ) * ( l2.p2.z - l2.p1.z );

  ////if the lines are zero length return
  //if ( pnorm == 0.0 || qnorm == 0.0 )
  //   return  -1.0;

  //return   arc_cosine(pdotq / ( pnorm * qnorm ));

  }
double misLine::length(void){
  return p1.distance(p2);
  }
///closest distance between two lines
//double misLine::distance(misLine 12){
//  //from http://www.csit.fsu.edu/~burkardt/cpp_src/geometry/geometry.html
//
//}
//---------------------------------------------------------------------------
// misGraphics2D
//---------------------------------------------------------------------------
#if !defined(misGraphics2D_H)
  #define misGraphics2D_H

#include <GL/glut.h>
#include <string>
#include <iostream>
#include <vector>

using std::string;
using std::vector;
//guide is the stylus that is moving with the user.

///@NOTE: init creates the bmp fonts which are window specific and need to be created
///after the window is created
///they are also initiliazed once (singleton) even in case of many instances of graphics2D

///the screen is set up so the buttom left is zero zero and upper right is x,y max.
/// width is x and y is height.
///if you are creating your own raster graphics use the setPosition function
///which adjust the y axis
///otherwise you have to subract your y value from the yMax of the screen (height)

class misGraphics2D {
public:
  ///constructor
  misGraphics2D(void);
  ///destructor
  ~misGraphics2D(void);
  //initialize the fonts and 
  static void init(void); 
  ///removes the allocated memory for this class 
  static void destroy(void);
  ///predefined colors 
  enum COLOR { BLACK, RED, GREEN,
               BLUE, YELLOW, CYAN,
               MAGENTA, WHITE, GRAY,
               AQUA, FUCHSIA, LIME,
               MAROON, NAVY, OLIVE,
               PURPLE, SILVER, TEAL,
               ORANGE,  PINK}; 
 
  /// draw a cross with center at x,y and full arm length
  void draw2DAxes(int x, int y, double length, int width=2);
  ///draws a circle in 2d, accepts size of circle plus number of segments
  void draw2Dcircle(int x, int y,double radius, double thickness=2, int segments=36);
  ///draws a solid circle
  void draw2DcircleSolid(int x, int y, double radius, int segments=36);
  ///draws text somewhere in space (text always faces the user.)
  ///font point size 10,12,14,16,18,20,22,24,26,28,32,36,48,60,72,100,150,200;
  ///draws the text on the screen
  void draw2DText(int x, int y, int size , string s);
  ///draw a point pixel
  void draw2DPoint(double x,double y, int size=4);
  ///draw arrow ....NOT IMPLEMENTED.
 // void draw2DArrow(double length, int width=2);
  ///draw line
  void draw2DLine(int x1,int y1,int x2,int y2,int width=2);
  /// draws a flat rectangle defined by the two points
  void draw2DRectangle(int x1,int y1,int x2,int y2);
   /// set the default color using predefined color and alpha channel ( transparency
  void setColor(COLOR c=BLACK, double a=1);
  ///life of PI
  static double PI;
  ///life of convert from radiants to degrees.
  static double PI_DIV_180;  
  ///sets the absolute position of raster graphics.
  ///x is from left to right across the screen with zero on the left. and +maxX on the right
  ///y is from top to bottom
  void setPosition2D(int x, int y);
  ///gets the width and height of the screen
  ///enter2D should be called to get the latest values of 
  int getScreenMaxX(void);
  int getScreenMaxY(void);
  ///displays the demo font sizes
  void demo2DText(void);

protected:

  ///holds color data
  double color[4];
  void glColor(void);
  ///holds flag for initialization.
  static bool initialized;
   //needs to placed in scene init
  static void buildFont(void);
  //needs to placed in the destructure of scene
  static void killFont(void);
  ///width and height of the screen
  int w, h;
  /// works with displaying txt or drawing flat on the screen.
  void enter2dMode();
  void exit2dMode();
  ///memory place holder for quadratic.
  static GLUquadricObj * QObj;
  ///prints text on the screen
  void text(int size, string s);
  ///converts double to a string with .
  string convToString(double d);
   ///converts int to a string with .
  string convToString(int i);
  ///converts string.
  string convToString2(double d);
  ///converts string.
  string convToString3(double d);
  string convToString4(double d);
  ///void glPrint(const char * fmt,...);
  void getScreenDims(void);
  ///place holders for font bmaps
  static GLuint base10,base12,base14,base16,base18,base20,base22,base24,base26,base28,base32,base36,base48,base60,base72,base100;

};

#endif // misDrillGuide_H



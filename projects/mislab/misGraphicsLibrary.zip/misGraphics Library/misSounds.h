#if !defined(misSounds_H)
  #define misSounds_H

#include <stdlib.h>
#include "fmod.h"
#include "fmod_errors.h"
#include <iostream>

#ifdef WIN32
	#include <windows.h>
	// link to fmod lib
	#pragma comment(lib,"fmod.lib")
#else
	#include <wincompat.h>
#endif

#include <string>
#include <iostream>

using namespace std;


class misSounds
{
public:
  misSounds(void);
  ~misSounds(void);
   
  enum WAV{CLOSE, BEEP,BUTTON,OK ,ERR, BYE, STARTUP, SHUTDOWN, TEST, CRAZY, FUN};
  ///
  void playSound(WAV w=BUTTON);

  ///INIT has to be called after window is created 
  ///called once
  static void init(void);
  ///called once upon the destruction of the program.
  ///destroys the allocated memory.
  static void destroy(void);
  static bool onFlag;
private:
    static bool initialized;  
  /// this is a pointer to the mp3 stream we will be reading from the disk.
    static FSOUND_SAMPLE* beepSample, *buttonSample,*nextSample,*errorSample, *byeSample;
    static FSOUND_SAMPLE* startupSample, *shutdownSample,*funSample,*crazySample, *testSample;
    static bool load (void);
};

#endif
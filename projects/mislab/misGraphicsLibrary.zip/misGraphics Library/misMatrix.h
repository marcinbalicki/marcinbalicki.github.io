#ifndef misMatrix_H
  #define misMatrix_H
  #include <iostream>
  #include <time.h>
  #include <iomanip>
  #include <string>
  #include <iosfwd>
  #include <sstream>
  #include <fstream>
  #include "misPoint.h"
#include "misGraphics3D.h"

using namespace std;

////ROW ORDER!
//X VECTOR IS ON THE FIRST ROW WITH the X ELEMENT ON THE LAST COLUMN!!!
//_matrix[0] = xAxis.x;
//_matrix[1] = xAxis.y;
//_matrix[2] = xAxis.z;
//_matrix[3] = 0;
//_matrix[4] = yAxis.x;
//_matrix[5] = yAxis.y;
//_matrix[6] = yAxis.z;
//_matrix[7] = 0;
//_matrix[8] = zAxis.x;
//_matrix[9] = zAxis.y;
//_matrix[10] = zAxis.z;
//_matrix[11] = 0;
//_matrix[12] = origin.x;
//_matrix[13] = origin.y;
//_matrix[14] = origin.z;
//_matrix[15] = 1;

 //matrix[0] = r11;
 //matrix[1] = r21;
 //matrix[2] = r31;
 //matrix[3] = 0;
 //matrix[4] = r12;
 //matrix[5] = r22;
 //matrix[6] = r32;
 //matrix[7] = 0;
 //matrix[8] = r13;
 //matrix[9] = r23;
 //matrix[10] = r33;
 //matrix[11] = 0;
 //matrix[12] = tipPosition.x;
 //matrix[13] = tipPosition.y;
 //matrix[14] = tipPosition.z;
 //matrix[15] = 1;


///Adapted from:
////http://www.nigels.com/glt/doc/class_matrix.html
///Translation Element is Located in a12,a13,a14;

/* 
a1 a2 a3 a4 a    typical       1 0 0 0
a5 a6 a7 a8      translation   0 1 0 0
a9 a10 a11 a12   matrix -->    0 0 1 0
a13 a14 a15 a16                -2 5 3 1
*/


/* openGL does this I think 
a1 a5 a9 a13    a typical   1 0 0 7
a2 a6 a10 a14   translation 0 1 0 6
a3 a7 a11 a15   matrix -->  0 0 1 9
a4 a8 a12 a16               0 0 0 1
*/
//If you declare a matrix as m[4][4], then the element m[i][j] is in
//the ith row and jth column of the OpenGL transformation matrix //[3,0]=a12=x
//[3,1]=a13=y //[3,2]=a14=z   

///NOTE: Usage
/// Point Transformations:
/// this matrix is the transformation from base to the new frame.
/// to get the location of the origin point of the new frame in the base frame
/// (*this)*pt(0,0,0) = pt_base(x,y,z) 

/// b     n    b
///   T *  P =  P
/// n

/// pt1_base(1,1,1) in the base frame
/// (*this).inverse()* pt1_base(1,1,1) will generate the location of that point (orginally
///  in base frame ) as viewed from the new frame

/// b -1   b    n
///   T  *  P =  P
/// n

/// b      n     b
///  T  *   T  =  T      (base to stylus transform )
/// n      s     s

/// use inverse to get the notation correct
/// n -1    n    s
///  T   *   T =  T
/// s       b    b

class misMatrix: public misGraphics3D {
public:
  misMatrix(void);
  ///constructor accepts another misMatrix
  misMatrix(const misMatrix & m);
  ///takes a 16 element array.
  misMatrix(const double *);
  //misMatrix(const double a[4][4]);
  ///takes in 3 points and creates a coordinate system out of it
  ///see create
  misMatrix(misPoint p1, misPoint p2, misPoint p3){ create(p1,p2,p3);};
  ///takes 2 points and creats a matrix with z defined by the 2 points
  ///origin is at p1.
   misMatrix(misPoint p1, misPoint p2){createZ(p1,p2);};
  ~misMatrix(void);
  ///sets the 16 element array
  void set(const double *);
  ///returns the pointer for the 16 element array
  double * get(void);
  //no idea what this does
  misMatrix & operator = (const misMatrix &);
  //multiplies two matrices 
  //ie. home to tracker transform = trackerMatrix.
  //if tool transform represents the relationship from tracker to tool
  //then trackerMatrix*toolMatrix will yield a matrix that represents the transform
  //from home to the tool.
  misMatrix operator * (const misMatrix &) const;
  //multiplies two matrices today
  misMatrix preMultiply (const misMatrix &) const;

  //multiplies and sets the results(post?)
  misMatrix & operator *= (const misMatrix &);
  
  //multiplies the point by the matrix (translates it into the frame)
  //the point in the matrix frame is translated to the base of that frame
  //ie point in the tracker frame p(3,4)
  //home to tracker transform  trackerMatrix
  //trackerMatrix*p -> yields the same point in the home frame

  misPoint operator * (const misPoint &) const;

  //loads identity values into the matrix
  void reset();
  //makes identity
  void identity();
  //checks if it is the identity matrix.
  bool isIdentity() const;
  //returns element
  double & operator[] (const int i);
  ///returns the matrix element
  const double & operator[] (const int i) const;
  ///I don't know what this does
  operator double * ();
  ///???
  operator const double * () const;
  ///checks if the two matrices are equal
  bool operator == (const misMatrix &) const;
  ///checks if the two matrices
  bool operator != (const misMatrix &) const;
  //calculates the inverse
  misMatrix inverse() const;
  ///returns the transpose.
  misMatrix transpose() const;
  ///returns the determinant
  double det() const;
  /// this returns the matrix in a string format.
  std::ostream & writePov(std::ostream & os) const;

  ///create from 3 points (p1 is the origin, p2 is the x , p3 is the y planes)
  void create(misPoint p1, misPoint p2, misPoint p3);
  
  ///create from 3 points (p1 is the origin, p2 is the x , p3 is the y planes)
  void createZ(misPoint p1, misPoint p2);
  ///print the matrix on command line 
  void print(void);
  /// saves the matrix to a file
  bool saveToFile(string fileName);
  /// draws the long and short axes
  void draw(void);
  ///  draw the label with the position of the origin
  void drawLabel(string label="");
  ///draws the direction of the transform from base to this matrix
  ///base is the current opengl frame
  ///use color to get the correct  
  void drawTransformDirection(double diaSize=2);
  ///multiplies the current gl matrix by this matrix
  void glMultiply(void);
  ///accessor to the
  ///change this to points
  misPoint getOrigin(void){return misPoint(_matrix[12],_matrix[13],_matrix[14]);};
  /// set the points
  void setOrigin(misPoint p) {_matrix[12]=p.x;_matrix[13]=p.y;_matrix[14]=p.z;};
  
  
  //x  stylus tip roll angle. 
      //y  stylus tip pitch angle. 
      //z  stylus tip yaw angle. 
      misPoint getOrientation(void);

  ///rotates the current matrix around its X axis in degrees
  ///returns the resultant matrix
  misMatrix rotX(double alpha);
  ///rotates the current matrix around its Y axis in degrees
  ///returns the resultant matrix
  misMatrix rotY(double alpha);
  ///rotates the current matrix around its Z axis in degrees
  ///returns the resultant matrix
  misMatrix rotZ(double alpha);
  ///returns a new matrix with the same rotation as this matrix but with a new 
  ///translated origin..
  misMatrix matTranslate(double x, double y, double z);

  void drawXY(double xDim,double yDim);
   void drawXZ(double xDim,double yDim);

private:
  ///no idea what this is
  friend std::ostream &
       operator << (std::ostream & os, const misMatrix & m);
  ///no idea what this does either.
  friend std::istream & operator >> (std::istream & is, misMatrix & m);
  ///the storage container for the matrix values
  double _matrix[16];
  ///define identity its static for everyone to use without
  static double _identity[16];
  ///sets values for a particular elements
  inline void set(const int col, const int row, const double val) {
    _matrix[col * 4 + row] = val;
  }
  ///gets the value
  inline double get(const int col, const int row) const {
    return _matrix[col * 4 + row];
  }
  ///returns the value
  inline double & element(const int col, const int row) {
    return _matrix[col * 4 + row];
  }
  /// From Mesa-2.2\src\glu\project.c
  static void invertMatrixGeneral(const double * m, double * out);
  static void invertMatrix(const double * m, double * out);
};

#endif





#include "misfacet.h"

misFacet::misFacet(void)
	{
	clear();
	}

misFacet::~misFacet(void)
	{
	}

void misFacet::clear(void)
	{
	normal.x=0.0;
	normal.y=0.0;
	normal.z=0.0;
	vertex[0].x=0.0;
	vertex[0].y=0.0;
	vertex[0].z=0.0;
	vertex[1].x=0.0;
	vertex[1].y=0.0;
	vertex[1].z=0.0;
	vertex[2].x=0.0;
	vertex[2].y=0.0;
	vertex[2].z=0.0;
	}

#if !defined(misLine_H)
  #define misLine_H
#include "misPoint.h"
#include "misGraphics3D.h"
#include "misMatrix.h"


///
/// when using the angle calculation feature consider the direction 
/// P1 faces 

class misLine: public misGraphics3D {
public:
  ///blank constructor ...should not be used really.
  misLine(void);
  ///create a line from these two points
  misLine(misPoint, misPoint);
  ///destructor
  ~misLine(void);
  ///set the first point defining the line
  void setP1(double, double, double);
  ///set the second point defining the line
  void setP2(double, double, double);
   ///set the first point defining the line
  void setP1(misPoint);
  ///set the second point defining the line
  void setP2(misPoint);
  ///get the first point defining the line
  misPoint getP1(void) { return p1; };
  ///set the second point defining the line
  misPoint getP2(void) { return p2; };
  ///calculate the length of the line
  double length(void);

  ///returns the normalized direction vector of the line.
  misPoint getDirVector(void) {return dirVector;};

  ///calculate the angles projected on different planes
  ///ORDER or POINTS MATTERS!
  void calculate(void);
  
  ///returns midpoint 
  misPoint midpoint(void){return midPoint;};
  ///draws a cylinder as the line the ends are spheres
  ///the radius is the width/2 of the "pipe"
  void draw(double radius);
  ///draws the labels on each end of the line
  void drawLabel(string label); 
  ///draw labels of the angles
  void drawAnglesLabel(string label);
  ///angle towards Z in ZX plane 
  double getAngleZX(void) {return angleZX;};
  ///angle towards Z in YZ plane 
  double getAngleYZ(void){return angleYZ;};
  ///angle towards X in XY plane 
  double getAngleXY(void){return angleXY;};
  
  ///angle between the two lines (absolute)
  double getAngle(misLine l2);
  ///distance between p1s from both lines
  double distanceP1(misLine l2);
  ///distance between p2s from both lines
  double distanceP2(misLine l2);
  ///closest distance between two lines
  /// double distance(misLine 12);

private:
  double angleZX, angleYZ, angleXY;
  misPoint midPoint;
  misPoint p1;
  misPoint p2;
  misPoint dirVector;
};
#endif


#include "misSounds.h"

bool misSounds::initialized=false;
FSOUND_SAMPLE* misSounds::beepSample=NULL;
FSOUND_SAMPLE* misSounds::buttonSample=NULL;
FSOUND_SAMPLE* misSounds::nextSample=NULL;
FSOUND_SAMPLE* misSounds::errorSample=NULL;
FSOUND_SAMPLE* misSounds::byeSample=NULL;
FSOUND_SAMPLE* misSounds::startupSample=NULL;
FSOUND_SAMPLE* misSounds::shutdownSample=NULL;
FSOUND_SAMPLE* misSounds::funSample=NULL;
FSOUND_SAMPLE* misSounds::crazySample=NULL;
FSOUND_SAMPLE* misSounds::testSample=NULL;

bool misSounds::onFlag=false;
misSounds::misSounds(void)
{  
}  

misSounds::~misSounds(void)
{
}

void misSounds::init(void){
  if (!initialized){
     // initialise fmod, 44000 Hz, 64 channels
	    if( FSOUND_Init(44000,64,0) == FALSE )
	    {
		    std::cerr << "[ERROR] Could not initialise fmod\n";
         cout<<"SOUND PROBLEM"<<endl;
		    return;
	    }
  
      if (!load())
          return;
  }
   initialized=true;
}
void misSounds::destroy(void){
      if (initialized){
      // kill off fmod frees all samples also.
//       playSound(SHUTDOWN);
	     FSOUND_Close();
       initialized=false; 
      }
}

bool misSounds::load(void){
  // attempt to open the mp3 file as a stream

	     beepSample=FSOUND_Sample_Load(FSOUND_FREE,"files/sounds/boing_1.wav",FSOUND_2D,0,0);
       buttonSample=FSOUND_Sample_Load(FSOUND_FREE,"files/sounds/click1.wav",FSOUND_2D,0,0);
       nextSample=FSOUND_Sample_Load(FSOUND_FREE,"files/sounds/next.wav",FSOUND_2D,0,0);
       errorSample=FSOUND_Sample_Load(FSOUND_FREE,"files/sounds/doh.wav",FSOUND_2D,0,0);
       byeSample=FSOUND_Sample_Load(FSOUND_FREE,"files/sounds/aladdin_goodbye.wav",FSOUND_2D,0,0);
       startupSample=FSOUND_Sample_Load(FSOUND_FREE,"files/sounds/startup.wav",FSOUND_2D,0,0);
       shutdownSample=FSOUND_Sample_Load(FSOUND_FREE,"files/sounds/shutdown_1.wav",FSOUND_2D,0,0);
       funSample=FSOUND_Sample_Load(FSOUND_FREE,"files/sounds/aladdin_goodbye.wav",FSOUND_2D,0,0);
       crazySample=FSOUND_Sample_Load(FSOUND_FREE,"files/sounds/yourcrazy.wav",FSOUND_2D,0,0);
       testSample=FSOUND_Sample_Load(FSOUND_FREE,"files/sounds/computer.wav",FSOUND_2D,0,0);

  if ( beepSample && buttonSample &&  nextSample &&  errorSample && byeSample)
    {   
       cout<<"Loaded all sound files OK!"<<endl;       
       return true;
    }
  else   
    {
       cout<<"ERROR: SOUND files not loaded!"<<endl;
       std::cerr << "[ERROR] could not open file\n";
      return false;
    }
}   

void misSounds:: playSound(WAV w){
    // start the sound playing
  if (!onFlag)
    return;

  int ch;
  switch (w){
   case BEEP:
       ch = FSOUND_PlaySound(FSOUND_FREE, beepSample);
       break;
  case BUTTON:
        ch = FSOUND_PlaySound(FSOUND_FREE,buttonSample);
       break;
   case OK:
       ch = FSOUND_PlaySound(FSOUND_FREE,nextSample);
       break; 
   case ERR:
       ch = FSOUND_PlaySound(FSOUND_FREE,errorSample);
        break;
  case BYE:
       ch = FSOUND_PlaySound(FSOUND_FREE,byeSample);
        break;
  case  STARTUP:
       ch = FSOUND_PlaySound(FSOUND_FREE,startupSample);
        break;

   case SHUTDOWN:
       ch = FSOUND_PlaySound(FSOUND_FREE,shutdownSample);
        break;

   case  TEST:
       ch = FSOUND_PlaySound(FSOUND_FREE,testSample);
        break;

   case  CRAZY:
       ch = FSOUND_PlaySound(FSOUND_FREE,crazySample);
        break;
   case   FUN:
       ch = FSOUND_PlaySound(FSOUND_FREE,funSample);
        break;
 }
   // make the sound loop
   //	FSOUND_SetLoopMode(ch,FSOUND_LOOP_NORMAL);
}

#include "misbmp.h"


misBMP::misBMP(void)
{
 // height=0;
 // width=0;
}

misBMP::~misBMP(void)
{
  if (info.Data!=NULL)
   free(info.Data);
}


bool misBMP::load(string fileName){
  //rotate the image to the opengl standard. 
  pngSetStandardOrientation(1);
   if (!pngLoadRaw(fileName.c_str(), &info)) {
			std::cout <<"\""<< fileName<<"\""<<" not found or not a png. Load Failed Looser!"<<std::endl;
			return false; 
   }
   std::cout <<"\""<< fileName<<"\""<<" read successfully."<<std::endl;
   printInfo();  
  //test if the png is 32 bit, otherwise stop
   if((info.Depth*info.Components)==32){
    // height=info.Height;
    // width=info.Width;
     return true;
   }
   else{
     std::cout <<"\""<< fileName<<"\""<<" is not a 32 BIT file and will not display"<<std::endl;
     return false;
   }
}

void misBMP::draw(void){
    glDrawPixels(info.Width,info.Height,GL_RGBA, GL_UNSIGNED_BYTE,info.Data);
}
void misBMP::draw(double newW, double newH){

  //width and height are window sizes.

  GLfloat xscale, yscale;   /* Scaling of image */
  
  if (info.Data!=NULL){
 
    xscale  = newW / info.Width;
    yscale  = newH / info.Height;

  glPixelZoom(xscale, yscale);

  glDrawPixels(info.Width,info.Height,GL_RGBA, GL_UNSIGNED_BYTE,info.Data);
  glPixelZoom(1, 1);
  }
}

void misBMP::drawWithNewWidth(double newW){

  //width and height are window sizes.

  GLfloat xsize, ysize;     /* Size of image */
  GLfloat xscale, yscale;   /* Scaling of image */

  if (info.Data!=NULL)
  {
    xsize = newW;
    ysize = info.Height * xsize/info.Width;
   /* if (ysize > y)
    {
      ysize = y;
      xsize = info.Width * ysize / info.Height;
    }*/

    xscale  = xsize / info.Width;
    yscale  = ysize / info.Height;

    glPixelZoom(xscale, yscale);

  glDrawPixels(info.Width,info.Height,GL_RGBA, GL_UNSIGNED_BYTE,info.Data);
  glPixelZoom(1, 1);
  }
}
void misBMP::drawWithNewHeight(double newH){

  //width and height are window sizes.

  GLfloat xsize, ysize;     /* Size of image */
  GLfloat xscale, yscale;   /* Scaling of image */

  if (info.Data!=NULL)
  {
    ysize = newH;
    xsize = info.Width * ysize/info.Height;
    /* if (ysize > y)
    {
      ysize = y;
      xsize = info.Width * ysize / info.Height;
    }*/

    xscale  = xsize / info.Width;
    yscale  = ysize / info.Height;

    glPixelZoom(xscale, yscale);

  glDrawPixels(info.Width,info.Height,GL_RGBA, GL_UNSIGNED_BYTE,info.Data);
    glPixelZoom(1, 1);
  }
}
//
//void misBMP::draw(double newW, double newH){
//
//  //width and height are window sizes.
//
//  GLfloat xsize, ysize;     /* Size of image */
//  GLfloat xscale, yscale;   /* Scaling of image */
//
//  if (info.Data!=NULL)
//  {
//    xsize = x;
//    ysize = info.Height * xsize/info.Width;
//    if (ysize > y)
//    {
//      ysize = y;
//      xsize = info.Width * ysize / info.Height;
//    }
//
//    xscale  = xsize / info.Width;
//    yscale  = ysize / info.Height;
//
//    glPixelZoom(xscale, yscale);
//
//  glDrawPixels(info.Width,info.Height,GL_RGBA, GL_UNSIGNED_BYTE,info.Data);
//
//  }
//}

void misBMP::printInfo(void)
{
  cout<<"WIDTH:"<<info.Width<<endl;
  cout<<"HEIGHT: "<<info.Height<<endl;
  cout<<"COLOR BIT DEPTH: "<<info.Depth<<endl;
  cout<<"ALPHA: "<<info.Alpha<<endl;
  cout<<"SIZE: "<<info.Components<<endl;
  cout<<endl;
}
int  misBMP::getScaledHeightFromWidth(int newWidth){

if (info.Data==NULL)
   return 0;
else 
return info.Height * newWidth/info.Width;
}
int  misBMP::getScaledWidthFromHeight(int newHeight){
if (info.Data==NULL)
   return 0;
else 
return info.Width * newHeight/info.Height;
}
int misBMP::getH(void){
if (info.Data==NULL)
   return 0;
else {
  
  return info.Height;
  }
}
int misBMP::getW(void){
if (info.Data==NULL)
   return 0;
else {
   return info.Width;
  }
}
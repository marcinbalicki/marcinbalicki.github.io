#ifndef misFacet_H
  #define misFacet_H
#include "misPoint.h"

///class misFacet is a container for an stl facet 
///has 3 3 value vertices (xyz) and a vector (xyz) as a normal.
class misFacet
{
public:
  misFacet( void );
  ~misFacet( void );
  ///container for the 3 vertices of the triangle (facet)
  misPoint vertex[3]; // everything in stlFacet is accessible
  ///the vector that represents the 
  misPoint normal;
  ///resets the data in the misFacet container to 0
  void clear( void );
};
#endif

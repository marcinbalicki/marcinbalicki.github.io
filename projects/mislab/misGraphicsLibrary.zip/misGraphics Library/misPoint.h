#if !defined(misPoint_H)
  #define misPoint_H 

#include "misGraphics3D.h"
///misPoint class is used as a point container as well as a vector container.
///

class misPoint: public misGraphics3D  {
public:
  misPoint(void);
  ///create a point from 3 values.
  misPoint(const double & x, const double & y, const double & z);
  ///destructor
  ~misPoint(void);
  ///the coordinates of the point
  double x,y,z;                  
  ///NOTE: THIS DOES NOT MODIFY THE POINT CLASS, JUST RETURNS A NEW POINT!!!!
  misPoint normalize(void);
  ///normalize but this modifies itself  
  void normalizeSelf(void);
  ///returns the distance between two points
  double distance(misPoint);
  ///dotproduct
  double dotProduct(misPoint B);
  ///scales the point proportionally
  misPoint operator * (double scale);
  ///check if it is the same point
  bool operator == (misPoint rhs);
  /// subtract the points.
  misPoint operator - (misPoint);
  //cross product of this misPoint(A) and B
  //right hand rule AxB
  misPoint crossProduct(misPoint B);
  ///magniutde of the vector(distance from 0,0,0 to point)
  double magnitude(void);
  ///print the point coordinate to the command line
  void print(void);
  ///draws a sphere on the location of the point
  void draw(double radius=1);
  ///draws the points as pixels...not a sphere
  void drawPixel(int size=3);
  ///labels the point at its location
  void drawLabel(string label="");
  ///for calculations of angles of the vector please look at misLine class.

  ///positive and negative are related to the sign of the side on which the point lays 
  double getAngleZX(void);
  ///angle towards Z in YZ plane 
  double getAngleYZ(void);
  ///angle towards X in XY plane 
  double getAngleXY(void);

  ///these return relative angle differences between the vectors, 
  ///both the vectors need to be normalized prior to using this function!!!!
  ///angleZX (NORMALIZED??)
  ///sign direction is the same as the above.
  double getAngleZX(misPoint);
  ///angle towards Z in YZ plane  (NORMALIZED??)
  double getAngleYZ(misPoint);
  ///angle towards X in XY plane  (NORMALIZED??)
  double getAngleXY(misPoint);
  
  ///angle between the two vectors (absolute)
  double getAngle(misPoint vect2);
};
#endif

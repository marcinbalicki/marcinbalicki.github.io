#if !defined(misBMP_H)
  #define misBMP_H

#include <windows.h>
#include <wingdi.h>

#include <string>
#include <iostream>
#include <GL/glut.h>
#include <GL/glpng.h>
using namespace std;

/*
 * Bitmap file data structures are defined in <wingdi.h> under
 * Windows
 */

//adopted from from opengl superbible2

class misBMP
{
public:
  misBMP(void);
  ~misBMP(void);
  
  bool load(string fileName);
  //not implemented correctly yet
  void draw(void);
  //new size of the image proportions are not preserved 
  void draw(double newW, double newH);
  ///specify new width of the image, proportions are preserved
  void drawWithNewWidth(double newW);
   ///specify new height of the image, proportions are preserved
  void drawWithNewHeight(double newH);
  //double getHeight(void){return height;};
  //double getWidth(void){return width;};
  //these return the calculated scaled values
  int getScaledHeightFromWidth(int newWidth);
  int getScaledWidthFromHeight(int newHeight);

  int getH(void);
  int getW(void);
private:
  pngRawInfo info; 
  void printInfo(void);
  //double height;
  //double width;
};

#endif
//---------------------------------------------------------------------------
// misGraphics3D
//---------------------------------------------------------------------------
#if !defined(misGraphics3D_H)
  #define misGraphics3D_H

#include <GL/glut.h>
#include <string>
#include <iostream>
#include <vector>

using std::string;
using std::vector;

///NOTE: run INIT after the corresponding opengl window is created.
///the init creates a 
//

class misGraphics3D {
public:
  ///constructor
  misGraphics3D(void);
  ///destructor
  ~misGraphics3D(void);
  ///small xyz coordinate arrows
  void drawXYZAxes(void);
  ///longer version of xyz coord axis
  void drawLongXYZAxes(void);
  ///draws a grid wiht 1 cm degredations.
  void drawXYgrid(void);
  ///draws dotted representation of the xyz axis
  void drawXYZAxesThin(void);
  //draws text somewhere in space (text always faces the user.)
  void drawText3D(double x,double y,double z, string s);
  ///draws text 
  void drawText3Dbig(double x,double y,double z, string s);
  ///draw a point pixel
  void drawPoint(double x,double y,double z, int size);
  ///draw sphere
  void drawSphere(double radius);
  ///draw line
  void drawCylinder(double radius, double length);
  ///draw cone
  void drawCone(double startR, double endR, double length);
  ///draw arrow
  void drawArrow(double length, double width);
  ///predefined colors 
  enum COLOR { BLACK, RED, GREEN,
               BLUE, YELLOW, CYAN,
               MAGENTA, WHITE, GRAY,
               AQUA, FUCHSIA, LIME,
               MAROON, NAVY, OLIVE,
               PURPLE, SILVER, TEAL,
               ORANGE,  PINK};  

  /// set the default color using predefined color and alpha channel ( transparency
  void setColor(COLOR c=BLACK, double a=1);
  // set the default color
  void setColor(double r, double g, double b);
  ///set the default color this gets used before every draw.
  void setColor(double r, double g, double b, double a);
  ///sets the line width
  void setLineWidth(int w);
  ///INIT has to be called after window is created 
  static void init(void);
  ///destroys the allocated memory.
  static void destroy(void);
  ///draw rectangle
  void drawRectangle(double x, double y);
  ///sets this classes color as the current gl color 
  void glColor(void);
  ///life of PI
  static double PI;
  static double PI_DIV_180;
  
  void circle2D(double radius, double thickness, int segments);
  ///draws a solid circle
  void circle2Dsolid(double radius, int segments);

  ///
  void initLight(void);
  ///returns the array of color (do not go over size 4 of this array)
  double * getColor(void){return &color[0];};

protected:
  
  static bool initialized;  
  ///turns of lights and blending
  void enterNoLightMode(void);
  ///turns it back on.
  void exitNoLightMode(void);
  ///draws boring text anywhre.
  ///requires positioning using glRasterPos3f(x,y,z);
  void string3D(string s);
  ///18 point font
  void string3Dbig(string s);
  ///stores the current color
  double color[4];
  /// pointer the the GLU open 
  static GLUquadricObj * QObj;
  ///converts double to a string with .
  string convToString(double d);
  ///converts int to a string with .
  string convToString(int i);
  ///converts double string formatted.
  string convToString2(double d);
  ///draws a circle in 2d, accepts size of circle plus number of segments
    ///  Output of the following functions is in degrees 
  ///  The angle is computed using the ACOS function, and so 
  ///  lies between 0 and PI.  But if one of the lines is degenerate, 
  ///  the angle is returned as 0.0.
  double arc_cosine ( double c );
};

#endif // misDrillGuide_H



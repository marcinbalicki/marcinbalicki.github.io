#include "misplane.h"
#include <string>
#include <iostream>
#include <math.h>

using namespace std ;

//
//The standard equation of a plane in 3 space is
//
//Ax + By + Cz + D = 0
//The normal to the plane is the vector (A,B,C).
//
//Given three points in space (x1,y1,z1), (x2,y2,z2), (x3,y3,z3) the equation of the plane through these points is given by the following determinants.
//Expanding the above gives
//A = y1 (z2 - z3) + y2 (z3 - z1) + y3 (z1 - z2)
//B = z1 (x2 - x3) + z2 (x3 - x1) + z3 (x1 - x2)
//C = x1 (y2 - y3) + x2 (y3 - y1) + x3 (y1 - y2)
//- D = x1 (y2 z3 - y3 z2) + x2 (y3 z1 - y1 z3) + x3 (y1 z2 - y2 z1)
//
//
//Note that if the points are colinear then the normal (A,B,C) as calculated above will be (0,0,0).
//
//The sign of s = Ax + By + Cz + D determines which side the point (x,y,z) lies with respect to the plane. If s > 0 then the point lies on the same side as the normal (A,B,C). If s < 0 then it lies on the opposite side, if s = 0 then the point (x,y,z) lies on the plane.


misPlane::misPlane(void)
	{
		//default plane inline with local coordinate system 
	p1[0]=0.0;
	p1[1]=0.0;
	p1[2]=0.0;
	p2[0]=1.0;
	p2[1]=0.0;
	p2[2]=0.0;
	p3[0]=0.0;
	p3[1]=1.0;
	p3[2]=0.0;
	A=0;
	B=0;
	C=0;
	D=0;
	calculate();
	}
misPlane::~misPlane(void)
	{
	}
	
misPlane::misPlane(misPoint p1,misPoint p2,misPoint p3){

   setPoints(p1,p2,p3);
}
void misPlane::setPoints(misPoint point1,misPoint point2,misPoint point3)
{
  p1[0]=point1.x;
  p1[1]=point1.y;
  p1[2]=point1.z;
  p2[0]=point2.x;
  p2[1]=point2.y;
  p2[2]=point2.z;
  p3[0]=point3.x;
  p3[1]=point3.y;
  p3[2]=point3.z;
  calculate();
}
void misPlane::setP1(double px,double py,double pz)
	{
		p1[0]=px;
		p1[1]=py;
		p1[2]=pz;
		calculate();
	}
void misPlane::setP2(double px,double py,double pz)
	{
		p2[0]=px;
		p2[1]=py;
		p2[2]=pz;
		calculate();
	}
void misPlane::setP3(double px,double py,double pz)
	{
		p3[0]=px;
		p3[1]=py;
		p3[2]=pz;
		calculate();
	}
void misPlane::calculate(void)
	{
		A = p1[1]*(p2[2]-p3[2])+p2[1]*(p3[2]-p1[2])+p3[1]*(p1[2]-p2[2]);
		B = p1[2]*(p2[0]-p3[0])+p2[2]*(p3[0]-p1[0])+p3[2]*(p1[0]-p2[0]);
		C = p1[0]*(p2[1]-p3[1])+p2[0]*(p3[1]-p1[1])+p3[0]*(p1[1]-p2[1]);
		D = -(p1[0]*(p2[1]*p3[2]-p3[1]*p2[2])+p2[0]*(p3[1]*p1[2]-p1[1]*p3[2])+p3[0]*(p1[1]*p2[2]-p2[1]*p1[2]));
    //create the corresponding transform matrix.	 
    planeTransform.create(misPoint(p1[0],p1[1],p1[2]),misPoint(p2[0],p2[1],p2[2]),misPoint(p3[0],p3[1],p3[2]));
  }
//0 is also positive
bool misPlane::calcSign(misPoint pt)
{
  double res=A*pt.x+B*pt.y+C*pt.z+D;
  if (res<0)
    return false;
  else
    return true;
}
 //calculates the points on the plane
double misPlane::calculateX(double y, double z)
{
  if (A==0)
    return 0;
   else 
     return (-(B*y + C*z + D)/A); 
}
double misPlane::calculateY(double x, double z){
  if (B==0)
    return 0;
   else 
     return  (-(A*x + C*z + D)/B);
}
double misPlane::calculateZ(double x, double y){
  if (C==0)
    return 0;
   else 
    return (-(A*x + B*y +  D)/C);
}
 
misPoint misPlane::getNormal(void){
  //simply the coefficiants of the plane equations
  return misPoint(A,B,C);
}

void misPlane::drawXY(double xDim,double yDim){

  
  double r=0.5;
  
  glPushMatrix();
  planeTransform.glMultiply();
  glTranslatef(-xDim/2,-yDim/2,0);
  misGraphics3D::drawRectangle(xDim, yDim);
  
  
  //draw a bounding box
  
 	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,xDim);
  
  glTranslatef(0.0f, 0.0f, xDim);
  glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,yDim);
  
  glTranslatef(0.0f, 0.0f, yDim);
  glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,xDim);
 
  glTranslatef(0.0f, 0.0f, xDim);
  glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,yDim);

  glPopMatrix(); 

}


void misPlane::drawXZ(double xDim,double yDim){

  
  double r=0.5;
  
  glPushMatrix();
  planeTransform.glMultiply();
  glRotatef(90, 1.0, 0.0, 0.0);  //so that plane is drawn on the xz plane
  glTranslatef(-xDim/2,-yDim/2,0);
  misGraphics3D::drawRectangle(xDim, yDim);
  
  //draw a bounding box
  
  glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,xDim);
  
  glTranslatef(0.0f, 0.0f, xDim);
  glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,yDim);
  
  glTranslatef(0.0f, 0.0f, yDim);
  glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,xDim);
 
  glTranslatef(0.0f, 0.0f, xDim);
  glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,yDim);

  glPopMatrix(); 

}

void misPlane::drawLabel(string label)
  {
    string s=string("   ")+label;
    drawText3D(p1[0],p1[1],p1[2], s);
  }

  //Extracts angles between the two planes with this plane as the reference 
  //uses the normals
double misPlane::getAngleZX(misPlane rhs)
  {
     //comp plane - this plane (the normals that is)
	 return getNormal().getAngleZX( rhs.getNormal());
  }

  //angle towards Z in YZ plane 
double misPlane::getAngleYZ(misPlane rhs){
	
	return getNormal().getAngleYZ( rhs.getNormal());
  }
  //angle towards X in XY plane 
double misPlane::getAngleXY(misPlane rhs){
	return getNormal().getAngleXY( rhs.getNormal());
  }
  //angle between the two planes (absolute)
double misPlane::getAngle(misPlane rhs){

	//compare the the angle between the normals...
	//uses the point's getangle calculation between two vectors.
	return abs(getNormal().getAngle(rhs.getNormal()));
  }
  //distance between this plane and another plane along the normal of this plane (normal location 
double misPlane::distanceP1(misPlane rhs){
 
	//the distance should be calculated along the normal from the current plane
	//create a target frame matrix

	//1. Translate the rhs plane to the current plane's frame
	//2. find the z on the new rhs plane that has x=0, y=0
  misPlane newRHSplane;
  newRHSplane.setPoints(planeTransform.inverse()*rhs.getP1(),planeTransform.inverse()*rhs.getP2(),planeTransform.inverse()*rhs.getP3());
  return newRHSplane.calculateZ(0,0);
}

misPoint misPlane::lineIntersectionPoint(misPoint pt1, misPoint pt2)
     {
       misPoint p, n;
       double d;
       double denom, mu;

       /* Calculate the parameters for the plane */
	   n=getNormal();
       d = -n.x * p1[0] - n.y * p1[1] - n.z * p1[2];

       /* Calculate the position on the line that intersects the plane */
       denom = n.x * (pt2.x - pt1.x) + n.y * (pt2.y - pt1.y) + n.z * (pt2.z - pt1.z);
       if (fabs(denom) < 0.00001)
            /* Line and plane don't intersect = parrallel*/
              return misPoint(0, 0, 0);
       //else
       mu = -(d + n.x * pt1.x + n.y * pt1.y + n.z * pt1.z) / denom;
       p.x = pt1.x + mu * (pt2.x - pt1.x);
       p.y = pt1.y + mu * (pt2.y - pt1.y);
       p.z = pt1.z + mu * (pt2.z - pt1.z);
       return p;
	 }

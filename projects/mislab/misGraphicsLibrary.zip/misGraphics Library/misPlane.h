#if !defined(misPlane_H)
  #define misPlane_H
#include "misPoint.h"
#include "misMatrix.h"
#include "misGraphics3D.h"
#include <string>
using namespace std;


///Class: misPlane   
///TOD0: calculate angles between this and another plane (xy, zx, yz) 
///the p1 is the "origin" of the plane
///the p2 describes its x axis ... this is used for drawing the plane
///Ax+By+Cz+D=0;
class misPlane: public misGraphics3D  {
public:
  misPlane(void);
  ~misPlane(void);
  misPlane(misPoint, misPoint, misPoint);

  /// accepts 3 points defining 
  void setPoints(misPoint, misPoint, misPoint);
  /// set first point (origin)
  void setP1(double, double, double);
  /// set second point (x axis)
  void setP2(double, double, double);
  /// set third point (y axis)
  void setP3(double, double, double);
  ///return arguments of the plane equation
  double getA(void) { return A; };
  double getB(void) { return B; };
  double getC(void) { return C; };
  double getD(void) { return D; };
  /// calculates the plane equation arguments
  void calculate(void);
  ///returns the sign of f(x,y,z)=Ax+By+Cz+D;
  ///used to determine on which side of the plane the point is.
  bool calcSign(misPoint);
  ///calculates the points on the plane depending on the input
  double calculateX(double y, double z);
  double calculateY(double x, double z);
  double calculateZ(double x, double y);
  ///returns the normal vector for the plane (z axis)
  misPoint getNormal(void);
  
  ///returns the original plane points
  misPoint getP1(void){return misPoint(p1[0],p1[1],p1[2]);};
  misPoint getP2(void){return misPoint(p2[0],p2[1],p2[2]);};
  misPoint getP3(void){return misPoint(p3[0],p3[1],p3[2]);};

  ///draws the plane in the current coordinate system around the 
  ///points given  
  void drawXY(double xDim,double yDim);
  //draws a plane that is perpendicular to the above plane
  void drawXZ(double xDim,double yDim);
  ///labels the plane
  void drawLabel(string label="");

  ///Extracts angles between the two planes with this plane as the reference 
  ///the frame that hosts both planes defines the axes of calculation (
  ///uses the normals
  double getAngleZX(misPlane rhs);
  ///angle towards Z in YZ plane 
  double getAngleYZ(misPlane rhs);
  ///angle towards X in XY plane 
  double getAngleXY(misPlane rhs);
  ///angle between the two planes (absolute)...the angle between their normals.
  double getAngle(misPlane rhs);
  
  ///distance between this plane and another plane along the normal of this plane (normal location )
  double distanceP1(misPlane rhs);
  ///would be nice to have another function that accepts a different point on this plane
  misPoint lineIntersectionPoint(misPoint pt1, misPoint pt2);


private:
  /// the matrix associated with this plane
  misMatrix planeTransform;
  /// the point and argument containers.
  double p1[3];
  double p2[3];
  double p3[3];
  double A;
  double B;
  double C;
  double D;
};
#endif

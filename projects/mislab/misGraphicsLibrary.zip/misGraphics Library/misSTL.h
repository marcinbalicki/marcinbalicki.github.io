#if !defined(misSTL_H)
  #define misSTL_H
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <stdio.h>
#include <GL/glut.h>
#include "misFacet.h"
#include "misGraphics3D.h"
using namespace std;

///holds information regarding STL model
///STL model is in ASCII format
///needs to be created upon the cretion of display window (display context)

class misSTL : public misGraphics3D
{
public:
  misSTL( void );
  ~misSTL( void );
  ///imports an STL model. filename required
  bool import( string file );
  ///creates an opengl display list so it is quicker to display
  int createStlList( void );
  ///changes the size of the STL file.
  void setScale( float s );
  ///
  enum LIST {POLYGON, POINT };
  /// draws the stl using diplsay list , (list number required)
  void draw(LIST l=POLYGON);
  /// draws bounding box
  void drawBox( void );
  /// creates a vector container of points representing the stl
  /// basically the vertices of the STL
  void createPointVector( void );
  /// display list of the points
  int createPointList( void );
  /// number associated with the polygon model of the list
  int stlModelList;
  /// number associated with the point model of the list
  int pointModelList;
  /// attempt to alter the model
  void tryPerspective( void );
  /// moves the model from its original point so that the lower left of the boudning box is on the origin.
  void moveToOrigin( void );
  /// itterators
  typedef vector < misFacet >::iterator vectStlIter;
  typedef vector < misPoint >::iterator vectPtIter;
  /// holds the facets (_polygons ) that make up the stl model
  vector < misFacet > stlVector;
protected: 
  /// name of the stl file
  string fileName;
  /// file pointer
  FILE * m_FilePointer;
  /// required variables
  int TotalLists;
  float scale;
  int UnitL;
  int idList;
  ///
  float axisUnits[2];
  /// boudning box
  float lx, ly, lz, hx, hy, hz;
  /// data containers
  vector < misPoint > stlPtVector;
  vector < misFacet > stlVector2;

};
#endif
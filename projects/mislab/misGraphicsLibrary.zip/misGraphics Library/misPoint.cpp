#include "mispoint.h"
#include "math.h"
#include <iostream>
misPoint::misPoint(void) {
  x = 0.0;
  y = 0.0;
  z = 0.0;
}

misPoint::misPoint(const double & x, const double & y, const double & z) {
  this->x = x;
  this->y = y;
  this->z = z;
}

misPoint::~misPoint(void) { }

void misPoint::normalizeSelf(void) {
 double d = sqrt(x * x + y * y + z * z);
// don't divide by zero
 if (d == 0)
 return;
 x /= d;
 y /= d;
 z /= d;
}

misPoint misPoint::normalize(void) {
  double d = magnitude();
  //don't divide by zero
  if (d == 0)
    return misPoint(0, 0, 0);
  return misPoint(x / d, y / d, z / d);
}


double misPoint::distance(misPoint p2) {
  return sqrt(pow(x - p2.x, 2.0) + pow(y - p2.y, 2.0) + pow(z - p2.z, 2.0));
}

double misPoint::dotProduct(misPoint B)
  { 
 // std::cout<<(x * B.x + y * B.y + z * B.z)<< std::endl;
  return (this->x * B.x + this->y * B.y +this->z * B.z);
  }

misPoint misPoint::crossProduct(misPoint B) {
  // C shouldn't be A or B
  misPoint C;
  C.x = y * B.z -  B.y*z;
  C.y = z * B.x -  B.z*x;
  C.z = x * B.y -  B.x*y;
  return C;
}

misPoint misPoint::operator * (double scale) {
  // C shouldn't be A or B
  misPoint C;
  C.x = x * scale;
  C.y = y * scale;
  C.z = z * scale;
  return C;
}

misPoint misPoint::operator - (misPoint rhs) {
  // C shouldn't be A or B
  misPoint C;
  C.x = x - rhs.x;
  C.y = y - rhs.y;
  C.z = z - rhs.z;
  return C;
}

bool misPoint::operator == (misPoint rhs) {
  if (x == rhs.x && y == rhs.y && z == rhs.z)
    return true;
  else
    return false;
}

void  misPoint::print(void){
  std::cout<<" DEBUG>> POINT X: "<<x<<"  Y: "<<y<< "  Z: "<<z<<std::endl;   
  }
     
void misPoint::draw(double radius){
   glPushMatrix();
	   glTranslatef(x,y,z);
	  drawSphere(radius);
   glPopMatrix();
  }

void misPoint::drawPixel(int size){
  misGraphics3D::drawPoint(x,y,z,size);
  }

void  misPoint::drawLabel(string label)
  {
    string s=string("  ")+label + string(": "+ convToString(x)+", "+ convToString(y)+", "+ convToString(z));
    drawText3D(x,y,z,s);
  }

double misPoint::magnitude(void)
  {
   return sqrt(x * x + y * y + z * z);

  }

double misPoint::getAngleZX(void){
  
  misPoint zAxis(0.0,0.0,1.0);
  //CALCULATE ZX plane angle to Z  (angleZX)
  misPoint zxVector;
  zxVector=(*this);
  zxVector.y=0.0;
  ///needs to be normalized and save...otherwise the doproduct has to be devided by the product of 
  // vector magnitudes
  zxVector=zxVector.normalize();

  //dot product of the z axis vector and the line normalized direction vector with no y component.
  double angleZX= arc_cosine(zAxis.dotProduct(zxVector));
  //need to give the angle a sign:
  //if it is on the negative x side then the angle is negative 
  if (zxVector.x<0)
	angleZX*=-1;
  return angleZX;
}

double misPoint::getAngleYZ(void){
  
   misPoint zAxis(0.0,0.0,1.0);
  //CALCULATE YZ plane angle to Z (angleYZ)
  misPoint yzVector=(*this);
  yzVector.x=0.0;
  yzVector=yzVector.normalize();
  //dot product of the z axis vector and the line normalized direction vector with no y component.
  double angleYZ= arc_cosine(zAxis.dotProduct(yzVector));
  //need to give the angle a sign:
  //if it is on the negative y side then the angle is negative 
  if (yzVector.y<0)
	angleYZ*=-1;
  return angleYZ;
  }
///angle towards X in XY plane 
double misPoint::getAngleXY(void){
  //either z or x axis is the reference vector
 
  misPoint xAxis(1.0,0.0,0.0);

  // For non-unit vectors:
  // (1) normalize each vector (NOTE: otherwise devide the dot product by the product of the magnitudes of the vectors) 
  // (2) compute the dot product
  // (3) take the arc cos to get the angle. 
  // (4) calculate sign of the angle

  //CALCULATE XY plane angle to X (angleXY)
  misPoint xyVector=(*this);
  xyVector.z=0;
  xyVector=xyVector.normalize();
  
  //dot product of the x axis vector and the line normalized direction vector with no z component.
  double angleXY= arc_cosine(xAxis.dotProduct(xyVector));

  //need to give the angle a sign:
  //if it is on the negative y side then the angle is negative 
  if (xyVector.y<0)
	angleXY*=-1;
  return angleXY;
  }
  
///angle between the two vectors (absolute)
double misPoint::getAngle(misPoint vect2){
  // For non-unit vectors:
  // (1) normalize each vector,
  // (2) compute the dot product
  // (3) take the arc cos to get the angle.

	return arc_cosine(normalize().dotProduct(vect2.normalize()));
}
double misPoint::getAngleZX(misPoint rhs){
   
	return rhs.getAngleZX()- getAngleZX();
  }

  //angle towards Z in YZ plane 
double misPoint::getAngleYZ(misPoint rhs){
	
	return rhs.getAngleYZ()- getAngleYZ();
  }
  //angle towards X in XY plane 
double misPoint::getAngleXY(misPoint rhs){
	return rhs.getAngleXY()- getAngleXY();
}
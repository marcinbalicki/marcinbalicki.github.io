#include "misMatrix.h"
#include <cmath>
#include <cassert> 
#include <ctime>    // For time()  

using namespace std;

//#include <misc/string.h>
//#include <math/umatrix.h>


double misMatrix::_identity[16] =
  {
    1.0, 0.0, 0.0, 0.0,
    0.0, 1.0, 0.0, 0.0,
    0.0, 0.0, 1.0, 0.0,
    0.0, 0.0, 0.0, 1.0
  };

misMatrix::misMatrix(void) {

  reset();
  srand(time(0));  // Initialize random number generator.

  }

misMatrix::~misMatrix(void) { }

misMatrix::misMatrix(const misMatrix & matrix) { 
  (* this) = matrix;
  }

misMatrix::misMatrix(const double * m) {
  //real *i = _matrix;
  double * i = _matrix;
  for (int k = 0; k < 16; i++, m++, k++)
    * i = * m;
  }

void misMatrix::set(const double * m) {
  //real *i = _matrix;
  double * i = _matrix;
  for (int k = 0; k < 16; i++, m++, k++)
    * i = * m;
  }

double * misMatrix::get(void) { return & _matrix[0]; }

misPoint misMatrix::operator * (const misPoint & p) const {
  misPoint retP;
  retP.x = get(0, 0) * p.x + get(1, 0) * p.y + get(2, 0) * p.z + get(3, 0);
  retP.y = get(0, 1) * p.x + get(1, 1) * p.y + get(2, 1) * p.z + get(3, 1);
  retP.z = get(0, 2) * p.x + get(1, 2) * p.y + get(2, 2) * p.z + get(3, 2);
  return retP;
  }

misMatrix & misMatrix::operator = (const misMatrix & m) {
  memcpy(_matrix, m._matrix, sizeof(_matrix));
  return * this;
  }

//misMatrix misMatrix::postMultiply (const misMatrix & m) const {
//  misMatrix prod;
//  for (int c = 0; c < 4; c++)
//    for (int r = 0; r < 4; r++)
//      prod.set(c, r,
//           get(c, 0) * m.get(0, r) + get(c, 1) * m.get(1, r) + get(c, 2) *
//           m.get(2, r) + get(c, 3) * m.get(3, r));
//
//  return prod;
//}

misMatrix misMatrix::operator *(const misMatrix & m) const {
  misMatrix prod;
  for (int c = 0; c < 4; c++)
    for (int r = 0; r < 4; r++)
      prod.set(c, r,  get(0, r) * m.get(c, 0) + get(1, r) * m.get(c, 1) + get (2, r)*
      m.get(c, 2) + get(3, r) * m.get(c, 3));

  return prod;
  }

misMatrix & misMatrix::operator *= (const misMatrix & m) {
  // Potential optimisation here to
  // skip a temporary copy

  return (* this) = (* this) * m;
  }

/* misPoint misMatrix::operator*(const misPoint &v) const {
double prod[4] = { 0,0,0,0 };

for (int r=0;r<4;r++) { prod[0]+=v.x*get(0,r); prod[1]+=v.y*get(1,r);
prod[2]+=v.z*get(2,r); prod[r] += get(3,r); }

double div = 1.0 / prod[3];
return misPoint(prod[0]*div,prod[1]*div,prod[2]*div); } */
void misMatrix::reset() { memcpy(_matrix, _identity, 16 * sizeof(double)); }

void misMatrix::identity() { reset(); }

bool misMatrix::isIdentity() const {
  return !memcmp(_matrix, _identity, sizeof(_matrix));
  }

const double & misMatrix::operator[] (const int i) const {
  assert(i >= 0 && i < 16);
  return _matrix[i];
  }

double & misMatrix::operator[] (const int i) {
  assert(i >= 0 && i < 16);
  return _matrix[i];
  }

bool misMatrix::operator == (const misMatrix & m) const {
  return !memcmp(_matrix, m._matrix, sizeof(_matrix));
  }

bool misMatrix::operator != (const misMatrix & m) const {
  return memcmp(_matrix, m._matrix, sizeof(_matrix)) != 0;
  }

misMatrix::operator double * () { return _matrix; }

misMatrix::operator const double * () const { return _matrix; }

//void misMatrix::glMultMatrix() const
//{
// glMultMatrixd(_matrix);
//}

//void misMatrix::glLoadMatrix() const
//{
// glLoadMatrixd(_matrix);
//}


std::ostream & operator << (std::ostream & os, const misMatrix & m) {
  for (int r = 0; r < 4; r++)
    for (int c = 0; c < 4; c++)
      os << setw(10) << setfill(' ') << m.get(c, r) << (c == 3 ? '\n' : '\t');
  return os;
  }

std::istream & operator >> (std::istream & is, misMatrix & m) {
  for (int r = 0; r < 4; r++)
    for (int c = 0; c < 4; c++) {
      double tmp;
      is >> tmp;
      m.set(c, r, tmp);
      }
  return is;
  }

misMatrix misMatrix::inverse() const {
  misMatrix inv;
  invertMatrix(_matrix, inv._matrix);
  return inv;
  }

misMatrix misMatrix::transpose() const {
  misMatrix tmp;
  for (int i = 0; i < 4; i++)
    for (int j = 0; j < 4; j++)
      tmp.set(j, i, get(i, j));
  return tmp;
  }

//
// From Mesa-2.2\src\glu\project.c
//
//
// Compute the inverse of a 4x4 matrix. Contributed by scotter@lafn.org
//

void misMatrix::invertMatrixGeneral(const double * m, double * out) {
  /* NB. OpenGL Matrices are COLUMN major. */
#define MAT(m,r,c) (m)[(c)*4+(r)]

  /* Here's some shorthand converting standard (row,column) to index. */
#define m11 MAT(m,0,0)
#define m12 MAT(m,0,1)
#define m13 MAT(m,0,2)
#define m14 MAT(m,0,3)
#define m21 MAT(m,1,0)
#define m22 MAT(m,1,1)
#define m23 MAT(m,1,2)
#define m24 MAT(m,1,3)
#define m31 MAT(m,2,0)
#define m32 MAT(m,2,1)
#define m33 MAT(m,2,2)
#define m34 MAT(m,2,3)
#define m41 MAT(m,3,0)
#define m42 MAT(m,3,1)
#define m43 MAT(m,3,2)
#define m44 MAT(m,3,3)

  double det;
  double d12, d13, d23, d24, d34, d41;
  double tmp[16];
  /* Allow out == in. */

  /* Inverse = adjoint / det. (See linear algebra texts.) */
  /* pre-compute 2x2 dets for last two rows when computing */
  /* cofactors of first two rows. */
  d12 = (m31 * m42 - m41 * m32);
  d13 = (m31 * m43 - m41 * m33);
  d23 = (m32 * m43 - m42 * m33);
  d24 = (m32 * m44 - m42 * m34);
  d34 = (m33 * m44 - m43 * m34);
  d41 = (m34 * m41 - m44 * m31);

  tmp[0] = (m22 * d34 - m23 * d24 + m24 * d23);
  tmp[1] = -(m21 * d34 + m23 * d41 + m24 * d13);
  tmp[2] = (m21 * d24 + m22 * d41 + m24 * d12);
  tmp[3] = -(m21 * d23 - m22 * d13 + m23 * d12);

  /* Compute determinant as early as possible using these cofactors. */
  det = m11 * tmp[0] + m12 * tmp[1] + m13 * tmp[2] + m14 * tmp[3];

  /* Run singularity test. */
  if (det == 0.0) {
    /* printf("invert_matrix: Warning: Singular matrix.\n"); */
    memcpy(out, _identity, 16 * sizeof(double));
    }
  else {
    double invDet = 1.0 / det;
    /* Compute rest of inverse. */
    tmp[0] *= invDet;
    tmp[1] *= invDet;
    tmp[2] *= invDet;
    tmp[3] *= invDet;

    tmp[4] = -(m12 * d34 - m13 * d24 + m14 * d23) * invDet;
    tmp[5] = (m11 * d34 + m13 * d41 + m14 * d13) * invDet;
    tmp[6] = -(m11 * d24 + m12 * d41 + m14 * d12) * invDet;
    tmp[7] = (m11 * d23 - m12 * d13 + m13 * d12) * invDet;

    /* Pre-compute 2x2 dets for first two rows when computing */
    /* cofactors of last two rows. */
    d12 = m11 * m22 - m21 * m12;
    d13 = m11 * m23 - m21 * m13;
    d23 = m12 * m23 - m22 * m13;
    d24 = m12 * m24 - m22 * m14;
    d34 = m13 * m24 - m23 * m14;
    d41 = m14 * m21 - m24 * m11;

    tmp[8] = (m42 * d34 - m43 * d24 + m44 * d23) * invDet;
    tmp[9] = -(m41 * d34 + m43 * d41 + m44 * d13) * invDet;
    tmp[10] = (m41 * d24 + m42 * d41 + m44 * d12) * invDet;
    tmp[11] = -(m41 * d23 - m42 * d13 + m43 * d12) * invDet;
    tmp[12] = -(m32 * d34 - m33 * d24 + m34 * d23) * invDet;
    tmp[13] = (m31 * d34 + m33 * d41 + m34 * d13) * invDet;
    tmp[14] = -(m31 * d24 + m32 * d41 + m34 * d12) * invDet;
    tmp[15] = (m31 * d23 - m32 * d13 + m33 * d12) * invDet;

    memcpy(out, tmp, 16 * sizeof(double));
    }
#undef m11
#undef m12
#undef m13
#undef m14
#undef m21
#undef m22
#undef m23
#undef m24
#undef m31
#undef m32
#undef m33
#undef m34
#undef m41
#undef m42
#undef m43
#undef m44
#undef MAT
  }


// Invert matrix m. This algorithm contributed by Stephane Rehel
// <rehel@worldnet.fr>
//

void misMatrix::invertMatrix(const double * m, double * out) {
  /* NB. OpenGL Matrices are COLUMN major. */
#define MAT(m,r,c) (m)[(c)*4+(r)]

  /* Here's some shorthand converting standard (row,column) to index. */
#define m11 MAT(m,0,0)
#define m12 MAT(m,0,1)
#define m13 MAT(m,0,2)
#define m14 MAT(m,0,3)
#define m21 MAT(m,1,0)
#define m22 MAT(m,1,1)
#define m23 MAT(m,1,2)
#define m24 MAT(m,1,3)
#define m31 MAT(m,2,0)
#define m32 MAT(m,2,1)
#define m33 MAT(m,2,2)
#define m34 MAT(m,2,3)
#define m41 MAT(m,3,0)
#define m42 MAT(m,3,1)
#define m43 MAT(m,3,2)
#define m44 MAT(m,3,3)

  register double det;
  double tmp[16];
  /* Allow out == in. */

  if (m41 != 0. || m42 != 0. || m43 != 0. || m44 != 1.) {
    invertMatrixGeneral(m, out);
    return;
    }

/* Inverse = adjoint / det. (See linear algebra texts.) */

tmp[0] = m22 * m33 - m23 * m32;
tmp[1] = m23 * m31 - m21 * m33;
tmp[2] = m21 * m32 - m22 * m31;

/* Compute determinant as early as possible using these cofactors. */
det = m11 * tmp[0] + m12 * tmp[1] + m13 * tmp[2];

/* Run singularity test. */
if (det == 0.0) {
  /* printf("invert_matrix: Warning: Singular matrix.\n"); */
  memcpy(out, _identity, 16 * sizeof(double));
  }
else {
  double d12, d13, d23, d24, d34, d41;
  register double im11, im12, im13, im14;

  det = 1. / det;

  /* Compute rest of inverse. */
  tmp[0] *= det;
  tmp[1] *= det;
  tmp[2] *= det;
  tmp[3] = 0.;

  im11 = m11 * det;
  im12 = m12 * det;
  im13 = m13 * det;
  im14 = m14 * det;
  tmp[4] = im13 * m32 - im12 * m33;
  tmp[5] = im11 * m33 - im13 * m31;
  tmp[6] = im12 * m31 - im11 * m32;
  tmp[7] = 0.;

  /* Pre-compute 2x2 dets for first two rows when computing */
  /* cofactors of last two rows. */
  d12 = im11 * m22 - m21 * im12;
  d13 = im11 * m23 - m21 * im13;
  d23 = im12 * m23 - m22 * im13;
  d24 = im12 * m24 - m22 * im14;
  d34 = im13 * m24 - m23 * im14;
  d41 = im14 * m21 - m24 * im11;

  tmp[8] = d23;
  tmp[9] = -d13;
  tmp[10] = d12;
  tmp[11] = 0.;

  tmp[12] = -(m32 * d34 - m33 * d24 + m34 * d23);
  tmp[13] = (m31 * d34 + m33 * d41 + m34 * d13);
  tmp[14] = -(m31 * d24 + m32 * d41 + m34 * d12);
  tmp[15] = 1.;

  memcpy(out, tmp, 16 * sizeof(double));
  }

#undef m11
#undef m12
#undef m13
#undef m14
#undef m21
#undef m22
#undef m23
#undef m24
#undef m31
#undef m32
#undef m33
#undef m34
#undef m41
#undef m42
#undef m43
#undef m44
#undef MAT
  }
///create from 3 points (p1 is the origin, p2 is the x , p3 is the y planes)
void misMatrix::create(misPoint p1, misPoint p2, misPoint p3){
  //first point (p1) is the origin point (standard)
  //x axis is p2-p1;
  //y axis is p3-p1;
  //z is the cross product

  misPoint xAxis, yAxis, zAxis;
  xAxis.x = p2.x - p1.x;
  xAxis.y = p2.y - p1.y;
  xAxis.z = p2.z - p1.z;
  yAxis.x = p3.x - p1.x;
  yAxis.y = p3.y - p1.y;
  yAxis.z = p3.z - p1.z;

  //unit vectorize
  xAxis = xAxis.normalize();
  yAxis = yAxis.normalize();
  //the y axis is temporary (the the two vectors are rarely at right angle
  //but it can be used to get the z
  //yAxis = yAxis.normalize();
  zAxis = xAxis.crossProduct(yAxis);
  //need to normalize if the x and y were not perpendicular
  zAxis = zAxis.normalize();
  //now x and z are perpendicular unit vecotors so find the y axis
  yAxis = zAxis.crossProduct(xAxis);
  //yAxis = xAxis.crossProduct(zAxis);
  //since they were perpendicular I don't have to normalize y
  //but I will anyway
  yAxis = yAxis.normalize();
  //Draw it so I know whats going on.
  //draw line between tips.
  //now create the transformation matrix

  _matrix[0] = xAxis.x;
  _matrix[1] = xAxis.y;
  _matrix[2] = xAxis.z;
  _matrix[3] = 0;
  _matrix[4] = yAxis.x;
  _matrix[5] = yAxis.y;
  _matrix[6] = yAxis.z;
  _matrix[7] = 0;
  _matrix[8] = zAxis.x;
  _matrix[9] = zAxis.y;
  _matrix[10] = zAxis.z;
  _matrix[11] = 0;
  _matrix[12] = p1.x;
  _matrix[13] = p1.y;
  _matrix[14] = p1.z;
  _matrix[15] = 1;

  }

void misMatrix::print(void){
  cout<<"----------------------------------------------------------------"<<endl;
  cout<<_matrix[0]<<"   "<<_matrix[4]<<"   "<<_matrix[8]<<"   "<< _matrix[12]<<endl;
  cout<<_matrix[1]<<"   "<<_matrix[5]<<"   "<<_matrix[9]<<"   "<<_matrix[13]<<endl;
  cout<<_matrix[2]<<"   "<<_matrix[6]<<"   "<<_matrix[10]<<"   "<<_matrix[14]<<endl;
  cout<<_matrix[3]<<"   "<<_matrix[7]<<"   "<<_matrix[11]<<"   "<<_matrix[15]<<endl;
  }

bool misMatrix::saveToFile(string fileName)
  {
  time_t t;
  /* buffer for thread-safe localtime_r() */
  struct tm * tm;
  time(& t);
  tm = localtime(& t);
  char buf[25];
  //create a formated date time string
  sprintf(buf, "__D-%04d-%02d-%02d__T-%02d.%02d.%02d", (tm->tm_year) + 1900,
    (tm->tm_mon) + 1, tm->tm_mday, tm->tm_hour, tm->tm_min, tm->tm_sec);
  //create time string
  string timeStr(buf);
  //add it to file name
  fileName = fileName + timeStr + string(".txt");
  FILE * m_FilePointer;

  // Here we open the desired file for writing and return the file pointer
  m_FilePointer = fopen(fileName.c_str(), "w");

  // Check to make sure we have a valid file pointer
  if (m_FilePointer == NULL) { // Create an error message for the attempted
    cout << "Error Reading File: " << fileName << endl;
    return false;
    }
//write the file
// int i=0;
// Go through the file until we reach the end
//while (i<16) {
string mat0(convToString(_matrix[0]).c_str());
string mat1(convToString(_matrix[1]).c_str());
string mat2(convToString(_matrix[2]).c_str());
string mat3(convToString(_matrix[3]).c_str());
string mat4(convToString(_matrix[4]).c_str());
string mat5(convToString(_matrix[5]).c_str());
string mat6(convToString(_matrix[6]).c_str());
string mat7(convToString(_matrix[7]).c_str());
string mat8(convToString(_matrix[8]).c_str());
string mat9(convToString(_matrix[9]).c_str());
string mat10(convToString(_matrix[10]).c_str());
string mat11(convToString(_matrix[11]).c_str());
string mat12(convToString(_matrix[12]).c_str());
string mat13(convToString(_matrix[13]).c_str());
string mat14(convToString(_matrix[14]).c_str());
string mat15(convToString(_matrix[15]).c_str());
//convToString(_matrix[i]).c_str();
//  i++;
//}
string s(mat0 + "\n" + mat1 + "\n" + mat2+ "\n" + mat3 + "\n" + mat4 + "\n" + mat5 + "\n" + mat6 + "\n" + mat7 + "\n" + mat8 + "\n" + mat9 + "\n" + mat10 + "\n" + mat11 + "\n" + mat12 + "\n" + mat13 + "\n" + mat14 + "\n" + mat15);
fprintf(m_FilePointer, "%s \n", s.c_str());
// Close the file that we opened
cout << "File Saved: " << fileName << endl;
fclose(m_FilePointer);
return true;
  }

void misMatrix::draw(void){

  //draw an arrow from the base to this matrix:represents transformation
  //create a matrix that has the z aligned with the displacement from base to the current frame

  glPushMatrix();
  glMultiply();
  misGraphics3D::drawXYZAxes();
  misGraphics3D::drawXYZAxesThin();
  
  glPopMatrix();

  //draw the location of this frame  
  };

void misMatrix::drawTransformDirection(double diaSize){
 
  //the origin of the base matrix
  misPoint p0(0,0,0);
  //temporary point that will be placed at the origin of this matrix
  misPoint p1=getOrigin();
  //basically draws the cooridinate 0,0,0 after the transform is applied
  //this returns the origin of this frame in base frame.

  misMatrix tempM(p0,p1);
  tempM.setColor(getColor()[0],getColor()[1],getColor()[2],getColor()[3]);
  glPushMatrix();
   tempM.glMultiply();
   tempM.drawArrow(p0.distance(p1),diaSize);
  glPopMatrix(); 

  }

void misMatrix::glMultiply(){
  glMultMatrixd((*this));
  }     ///create from 3 points (p1 is the origin, p2 is the z )


void misMatrix::createZ(misPoint p1, misPoint p2){
  //first point (p1) is the origin point (standard)
  //z axis is p2-p1;  
  if (p1==p2){
    //cout<<"ERROR: misMatrix creation, points are equal!"<<endl;
    return;
    }

  // find 3d point 
  // the third point can be found after the 
  misPoint temp=p2-p1;
  temp.normalizeSelf();
  misPoint p3;
  
  //find a vector that is perpendicular to this normalized vector.
  //but first check if it is along the Z vector
  if (abs(temp.z)!=1){
     p3.x = -temp.y;
     p3.y = temp.x;
     p3.z = 0;
	 p3.normalizeSelf();
  }
  // but if it is we know that the other components are not zero together.
  // so we solve we set another component to 0
  else {
      p3.x = -temp.z;
      p3.y = 0;
      p3.z = temp.x;
	    p3.normalizeSelf();

  }

//move the points back to...

  misPoint xAxis, yAxis, zAxis;
  zAxis.x = p2.x - p1.x;
  zAxis.y = p2.y - p1.y;
  zAxis.z = p2.z - p1.z;

  yAxis=p3.normalize();

  //unit vectorize
  zAxis = zAxis.normalize();
  //the y axis is temporary (the the two vectors are rarely at right angle
  //but it can be used to get the z
  xAxis = yAxis.crossProduct(zAxis);
  //need to normalize if the x and y were not perpendicular
  xAxis = xAxis.normalize();
  //now x and z are perpendicular unit vectors so find the y axis
  yAxis = zAxis.crossProduct(xAxis);
  //yAxis = xAxis.crossProduct(zAxis);
  //since they were perpendicular I don't have to normalize y
  //but I will anyway
  yAxis = yAxis.normalize();
  //Draw it so I know whats going on.
  //draw line between tips.
  //now create the transformation matrix

  _matrix[0] = xAxis.x;
  _matrix[1] = xAxis.y;
  _matrix[2] = xAxis.z;
  _matrix[3] = 0;
  _matrix[4] = yAxis.x;
  _matrix[5] = yAxis.y;
  _matrix[6] = yAxis.z;
  _matrix[7] = 0;
  _matrix[8] = zAxis.x;
  _matrix[9] = zAxis.y;
  _matrix[10] = zAxis.z;
  _matrix[11] = 0;
  _matrix[12] = p1.x;
  _matrix[13] = p1.y;
  _matrix[14] = p1.z;
  _matrix[15] = 1;

  }

void misMatrix::drawLabel(string label){
  label=label + string(": "+ convToString(getOrigin().x)+", "+ convToString(getOrigin().y)+", "+ convToString(getOrigin().z));
  drawText3D(getOrigin().x,getOrigin().y,getOrigin().z,label);
  }


misMatrix misMatrix::rotX(double alpha){
  misMatrix mat;

  mat[0] = 1;
  mat[1] = 0;
  mat[2] = 0;
  mat[3] = 0;	
  mat[4] = 0;
  mat[5] = cos(alpha*(PI_DIV_180));
  mat[6] = sin(alpha*(PI_DIV_180));
  mat[7] = 0;
  mat[8] = 0;
  mat[9] = -sin(alpha*(PI_DIV_180));
  mat[10] = cos(alpha*(PI_DIV_180));
  mat[11] = 0;
  mat[12] = 0;
  mat[13] = 0;
  mat[14] = 0;
  mat[15] = 1;
  return (*this)*mat;
  }

misMatrix misMatrix::rotY(double alpha){

  misMatrix mat;
  mat[0] = cos(alpha*(PI_DIV_180));
  mat[1] = 0;
  mat[2] = -sin(alpha*(PI_DIV_180));
  mat[3] = 0;	
  mat[4] = 0;
  mat[5] = 1;
  mat[6] = 0;
  mat[7] = 0;
  mat[8] = sin(alpha*(PI_DIV_180));
  mat[9] = 0;
  mat[10] = cos(alpha*(PI_DIV_180));
  mat[11] = 0;
  mat[12] = 0;
  mat[13] = 0;
  mat[14] = 0;
  mat[15] = 1;
  return (*this)*mat;
  }

misMatrix misMatrix::rotZ(double alpha){
  misMatrix mat;
  mat[0] = cos(alpha*(PI_DIV_180));
  mat[1] = sin(alpha*(PI_DIV_180));
  mat[2] = 0;
  mat[3] = 0;	
  mat[4] = -sin(alpha*(PI_DIV_180));
  mat[5] = cos(alpha*(PI_DIV_180));
  mat[6] = 0;
  mat[7] = 0;
  mat[8] = 0;
  mat[9] = 0;
  mat[10] = 1;
  mat[11] = 0;
  mat[12] = 0;
  mat[13] = 0;
  mat[14] = 0;
  mat[15] = 1;
  return (*this)*mat;
  }

misMatrix misMatrix::matTranslate(double x, double y, double z){
  misMatrix mat = (*this);
  // misMatrix mat;
  mat[12] = mat[12]+x;
  mat[13] = mat[13]+y;
  mat[14] = mat[14]+z;

   return mat;

  }


void misMatrix::drawXY(double xDim,double yDim){

  
  double r=0.5;
  
  glPushMatrix();
  glMultiply();
  glTranslatef(-xDim/2,-yDim/2,0);
  misGraphics3D::drawRectangle(xDim, yDim);
  
  //draw a bounding box
  
  glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,xDim);
  
  glTranslatef(0.0f, 0.0f, xDim);
  glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,yDim);
  
  glTranslatef(0.0f, 0.0f, yDim);
  glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,xDim);
 
  glTranslatef(0.0f, 0.0f, xDim);
  glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,yDim);

  glPopMatrix(); 

}


void misMatrix::drawXZ(double xDim,double yDim){

  double r=0.5;
  
  glPushMatrix();
  glMultiply();
  glRotatef(90, 1.0, 0.0, 0.0);  //so that plane is drawn on the xz plane
  glTranslatef(-xDim/2,-yDim/2,0);
  misGraphics3D::drawRectangle(xDim, yDim);
  
  //draw a bounding box
  glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,xDim);
  
  glTranslatef(0.0f, 0.0f, xDim);
  glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,yDim);
  
  glTranslatef(0.0f, 0.0f, yDim);
  glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,xDim);
 
  glTranslatef(0.0f, 0.0f, xDim);
  glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
  drawSphere(r);
  drawCylinder(r,yDim);

  glPopMatrix(); 

}

//x  stylus tip roll angle. 
      //y  stylus tip pitch angle. 
      //z  stylus tip yaw angle. 
misPoint  misMatrix::getOrientation(void){
    
    //***************************************************not verified
   //****************************************************
    //matrix[0] = r11;
    //matrix[1] = r21;
    //matrix[2] = r31;
    //matrix[3] = 0;
    //matrix[4] = r12;
    //matrix[5] = r22;
    //matrix[6] = r32;
    //matrix[7] = 0;
    //matrix[8] = r13;
    //matrix[9] = r23;
    //matrix[10] = r33;
    //matrix[11] = 0;
    //matrix[12] = tipPosition.x;
    //matrix[13] = tipPosition.y;
    //matrix[14] = tipPosition.z;
    //matrix[15] = 1;

   //from introduction to robotics  (craig)

     //roll pitch yaw
    //xyz
     double x,y,z;
         y=atan2(-_matrix[2], sqrt (_matrix[0]*_matrix[0]+_matrix[1]*_matrix[1]));
         if (y==PI/2){
              z=0;
              x=atan2(_matrix[4],_matrix[5]);
           }
         else if (y==-PI/2){
              z=0;
              x=-atan2(_matrix[4],_matrix[5]);
           }
         else {
         z=atan2(_matrix[1]/cos(x),_matrix[0]/cos(x));
         x=atan2(_matrix[6]/cos(x),_matrix[10]/cos(x));
           }
     misPoint ang(x * 180 / PI,y * 180 / PI,z * 180 / PI);
     //this->print();
     return ang;


  }

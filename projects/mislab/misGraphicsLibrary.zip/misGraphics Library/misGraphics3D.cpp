//---------------------------------------------------------------------------
// misGraphics3D.cpp
//---------------------------------------------------------------------------

#include "misGraphics3D.h"
#include "math.h"
#include <windows.h>		// Header File For Windows
#include <iomanip>
#include <sstream>
#include <fstream>

using namespace std;

/* The most commonly used variant of the command to set RGBA colors
is glColor4f(GLfloat red, GLfloat green, GLfloat blue)
where red, green, and blue are values between 0.0 and 1.0, inclusive. The
value 0.0 corresponds to the minimum amount of that color while 1.0
corresponds to the maximum amount of that color. Commonly Used RGB Colors */

GLUquadricObj * misGraphics3D::QObj=NULL;

bool misGraphics3D::initialized=false;
double misGraphics3D::PI=3.141592653589793; 
double misGraphics3D::PI_DIV_180=misGraphics3D::PI/180.0;

misGraphics3D::misGraphics3D(void) {
  setColor();
}

misGraphics3D::~misGraphics3D(void) { }

string misGraphics3D::convToString(double d) {
  ///internal stream function used in toString()
  ostringstream oss;
  oss << setiosflags(ios_base::showpoint) << setiosflags(ios_base::right);
  oss << setiosflags(ios_base::fixed) << setprecision(1) << setw(4) <<
       setiosflags(ios_base::showpos) << d; // insert double into stream
  return oss.str();
}

string misGraphics3D::convToString(int i) {
  ///internal stream function used in toString()
  ostringstream oss;
  oss << setiosflags(ios_base::right);
  oss << setiosflags(ios_base::fixed) << setprecision(0) << setw(4) <<
       setiosflags(ios_base::showpos) << i; // insert double into stream
  return oss.str();
  }

string misGraphics3D::convToString2(double d) {
  ///internal stream function used in toString()
  ostringstream oss;
  oss << setiosflags(ios_base::right) << setiosflags(ios_base::showpos);
  oss << setw(4) << d; // insert double into stream
  return oss.str();
}

void misGraphics3D::circle2D(double radius, double thickness, int segments) {
   glColor();
	  gluDisk(QObj,radius - thickness,radius,segments,8 );
}

void misGraphics3D::circle2Dsolid(double radius, int segments) {
  /*  NEED TO APPLY THIS:
  
  void gluDisk(	GLUquadric* quad,
			GLdouble inner,
			GLdouble outer,
			GLint slices,
			GLint loops )
   PARAMETERS
	  quad	  Specifies the	quadrics object	(created with gluNewQuadric).
	  inner	  Specifies the	inner radius of	the disk (may be 0).
	  outer	  Specifies the	outer radius of	the disk.
 	  slices  Specifies the	number of subdivisions around the z axis.
	  loops	  Specifies the	number of concentric rings about the
		        origin into which the	disk is	subdivided.
     partial dISK IS ALSO POSSIBLE
  */
	glColor();
  gluDisk(QObj,0.0,radius,segments,8 );
}

void misGraphics3D::string3D(string s) {
	enterNoLightMode();
  glColor();
  unsigned int i;
	for (i = 0; i < s.size(); i++)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_10, s[i]);
  exitNoLightMode();
}

void misGraphics3D::string3Dbig(string s) {
	enterNoLightMode();
  glColor();
  unsigned int i;
	for (i = 0; i < s.size(); i++)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, s[i]);
   exitNoLightMode();
}


void  misGraphics3D::drawXYZAxes(void) {
	// draw golbal Origin & X-Y-Z axes
	glPushMatrix();
	// Red for the X-axis
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
	glColor4f(1.0f, 0.0f, 0.0f,1.0f);
	gluCylinder(QObj, 0.5f, 0.5f, 5.0f, 8, 1);
	glTranslatef(0.0f, 0.0f, 5.0f);
	gluCylinder(QObj, 0.75f, 0.0f, 3.5f, 8, 1);
	//glRasterPos2f(0,0);
	//drillGuide.text(3, string("X"));
	//drawString("X");
	glPopMatrix();
	glPushMatrix();
	// Green for the Y-axis
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glColor4f(0.0f, 1.0f, 0.0f,1.0f);
	gluCylinder(QObj, 0.5f, 0.5f, 5.0f, 8, 1);
	glTranslatef(0.0f, 0.0f, 5.0f);
	gluCylinder(QObj, 0.75f, 0.0f, 3.5f, 8, 1);
	// drawString("Y");
	glPopMatrix();
	glPushMatrix();
	// Blue for the Z-axis
	glColor4f(0.0f, 0.0f, 1.0f,1.0f);
	gluCylinder(QObj, 0.5f, 0.5f, 5.0f, 8, 1);
	glTranslatef(0.0f, 0.0f, 5.0f);
	gluCylinder(QObj, 0.75f, 0.0f, 3.5f, 8, 1);
	// drawString("Z");
	glPopMatrix();
	glPushMatrix();
	// the Origin sphere in White
	glColor4f(1.0f, 1.0f, 1.0f,1.0f);
	gluSphere(QObj, 1, 8, 8);
	glPopMatrix();

}

void misGraphics3D::drawLongXYZAxes(void) {
	// draw golbal Origin & X-Y-Z axes
	glPushMatrix();
	// Red for the X-axis
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
	glColor4f(1.0f, 0.0f, 0.0f,1.0f);
	gluCylinder(QObj, 0.2f, 0.2f, 200.0f, 8, 1);
	glTranslatef(0.0f, 0.0f, 200.0f);
	gluCylinder(QObj, 0.75f, 0.0f, 3.5f, 8, 1);
	//glRasterPos2f(0,0);
	//drillGuide.text(3, string("X"));
	//drawString("X");
	glPopMatrix();
	glPushMatrix();
	// Green for the Y-axis
	glRotatef(-90.0f, 1.0f, 0.0f, 0.0f);
	glColor4f(0.0f, 1.0f, 0.0f,1.0f);
	gluCylinder(QObj, 0.2f, 0.2f, 200.0f, 8, 1);
	glTranslatef(0.0f, 0.0f, 200.0f);
	gluCylinder(QObj, 0.75f, 0.0f, 3.5f, 8, 1);
	// drawString("Y");
	glPopMatrix();
	glPushMatrix();
	// Blue for the Z-axis
	glColor4f(0.0f, 0.0f, 1.0f,1.0f);
	gluCylinder(QObj, 0.2f, 0.2f, 200.0f, 8, 1);
	glTranslatef(0.0f, 0.0f, 200.0f);
	gluCylinder(QObj, 0.75f, 0.0f, 3.5f, 8, 1);
	// drawString("Z");
	glPopMatrix();
	glPushMatrix();
	// the Origin sphere in White
	glColor4f(1.0f, 1.0f, 1.0f,1.0f);
	gluSphere(QObj, 1, 8, 8);
	glPopMatrix();
}

void misGraphics3D::drawXYgrid(void) {
	float size = 50.0f; //100 mm (+50, -50)
	float div = 10.0f; //division size
	//glMatrixMode(GL_MODELVIEW);
	// draw golbal Origin & X-Y-Z axes
	glPushMatrix();
	glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
	glPushMatrix();
	// X-axis
	//glLoadIdentity();
	glColor4f(1.0f, 0.0f, 0.0f,1.0f);
	//glRotatef (spin, 1.0f, 1.0f, 0.0f);
	glRotatef(0.0f, 0.0f, 1.0f, 0.0f);
	glTranslatef(-size, 0.0f, 0.0f);
	glTranslatef(0.0f, 0.0f, -size);
	for (float f = -size; f <= size; f += div) {
		gluCylinder(QObj, 0.1f, 0.1f, size * 2.0f, 4, 4);
		glTranslatef(div, 0.0f, 0.0f);
	}
	//y axis
	glPopMatrix();
	glPushMatrix();
	glColor4f(1.0f, 0.0f, 0.0f,1.0f);
	//glRotatef (spin, 1.0f, 1.0f, 0.0f);
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
	glTranslatef(-size, 0.0f, 0.0f);
	glTranslatef(0.0f, 0.0f, -size);
	for (float f = -size; f <= size; f += div) {
		gluCylinder(QObj, 0.1f, 0.1f, size * 2.0f, 4, 4);
		glTranslatef(div, 0.0f, 0.0f);
	}
	glPopMatrix();
	glPopMatrix();

}

void  misGraphics3D::drawXYZAxesThin(void) {
	float size = 50.0f; //100 mm (+50, -50)
	float div = 1.0f; //division size
	// draw golbal Origin & X-Y-Z axes
	//glPolygonMode(GL_FRONT, GL_FILL);
	glPushMatrix();
	// the Origin sphere in White
	glColor4f(1.0f, 1.0f, 1.0f,1.0f);
	gluSphere(QObj, 1, 8, 8);
	// X-axis
	//glLoadIdentity();
	glColor4f(1.0f, 0.0f, 0.0f,1.0f);
	glTranslatef(-size, 0.0f, 0.0f);
	for (float f = -size; f <= size; f += div) {
		gluSphere(QObj, 0.25f, 4, 4);
		glTranslatef(div, 0.0f, 0.0f);
	}
	//y axis
	glPopMatrix();
	glPushMatrix();
	glColor4f(1.0f, 0.0f, 0.0f,1.0f);
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);
	glTranslatef(-size, 0.0f, 0.0f);
	for (float f = -size; f <= size; f += div) {
		gluSphere(QObj, 0.25f, 4, 4);
		glTranslatef(div, 0.0f, 0.0f);
	}
	//y axis
	glPopMatrix();
	glPushMatrix();
	glColor4f(1.0f, 0.0f, 0.0f,1.0f);
	glRotatef(90.0f, 0.0f, 0.0f, 1.0f);
	glTranslatef(-size, 0.0f, 0.0f);
	for (float f = -size; f <= size; f += div) {
		gluSphere(QObj, 0.25f, 4, 4);
		glTranslatef(div, 0.0f, 0.0f);
	}
	glPopMatrix();
}

  ///draw sphere
void  misGraphics3D::drawSphere(double radius){
     glColor(); 
     gluSphere(QObj,radius, 16, 16);
  }

  ///draw line
void  misGraphics3D::drawCylinder(double radius, double length){
    glColor();
    gluCylinder(QObj, radius, radius, length, 16, 1);
  }
  ///draw cone
void  misGraphics3D::drawCone(double startR, double endR, double length){
    glColor(); 
    gluCylinder(QObj,startR, endR, length, 16, 1);
  }
  ///draw arrow 0,0,0 is the back end
void  misGraphics3D::drawArrow(double length, double width)
  {
   glColor();
    glPushMatrix();
	  drawSphere(width/2.0);
    drawCylinder(width/2.0, length-width*2);
    glTranslatef(0.0f, 0.0f,length-width*2);
	  drawCone(width,0,width*2);
    glPopMatrix();
}
  /// set the default color
void  misGraphics3D::setColor(double r, double g, double b){
       color[0]=r;
       color[1]=g;
       color[2]=b;
       color[3]=1; 
       glColor4f(color[0],color[1],color[2], color[3]);
  }
  ///set the default color this gets used before every draw.
void  misGraphics3D::setColor(double r, double g, double b, double a){
      color[0]=r;
      color[1]=g;
      color[2]=b;
      color[3]=a;
      glColor4f(color[0],color[1],color[2], color[3]);
  }

void  misGraphics3D::setLineWidth(int w)
{
   glLineWidth(w);
}
///draw a point pixel
void  misGraphics3D::drawPoint(double x,double y,double z, int size){
  glColor();
  glPointSize(size);
   glBegin (GL_POINTS);
    glVertex3d(x,y,z);
   glEnd();
  }

void misGraphics3D::init(void){
  if (!initialized){
     QObj = gluNewQuadric();
      initialized=true; 
     
     //if (QObj!=NULL)
     //cout<<"Got an object "<<instanceCount<<endl;
     //else
     //  cout<<"NULL"<<endl;
    }
  //instanceCount++;
}
void misGraphics3D::destroy(void){
      if (initialized){
       gluDeleteQuadric(QObj);
       initialized=false; 
      }
}


///draw rectangle         
void misGraphics3D::drawRectangle(double x, double y){
   glColor();
  glBegin(GL_POLYGON);
      glVertex2f (0.0f, 0.0f);
      glVertex2f (x, 0.0f);
      glVertex2f (x, y);
      glVertex2f (0.0f, y);
   glEnd();
}

void misGraphics3D::enterNoLightMode(void){
  //if I am turning off and on some of the enbles/disables
  //I should just note what is on and turn it off.
  
  /* Push current matrix mode and viewport attributes. */
 // glPushAttrib(GL_TRANSFORM_BIT | GL_VIEWPORT_BIT | GL_COLOR_BUFFER_BIT);
 // glEnable(GL_LINE_SMOOTH);
 
  glDisable(GL_BLEND);
  glDisable(GL_LIGHTING);

  //lighting makes the text disapear for some reason.
  }

void misGraphics3D::exitNoLightMode(void){
   /* Restore matrices, viewport and matrix mode. */
   // glPopAttrib();
   // glDisable(GL_LINE_SMOOTH);
  
  glEnable(GL_BLEND);
  glEnable(GL_LIGHTING);
}

void misGraphics3D::glColor(void){
   glColor4f(color[0],color[1],color[2], color[3]);
  }
//draws text somewhere in space (text always faces the user.)
void misGraphics3D::drawText3D(double x,double y,double z, string s){
  glColor();
  glPushMatrix();
    glRasterPos3f(x,y,z);
    string3D(s);
  glPopMatrix();

  }

void misGraphics3D::drawText3Dbig(double x,double y,double z, string s){
  glColor();
  glPushMatrix();
    glRasterPos3f(x,y,z);
    string3Dbig(s);
  glPopMatrix();
  }
//arc cosine in degrees
double misGraphics3D::arc_cosine ( double c ){
// from http://www.csit.fsu.edu/~burkardt/cpp_src/geometry/geometry.html
//  Discussion:
//
//    If you call your system ACOS routine with an input argument that is
//    outside the range [-1.0, 1.0 ], you may get an unpleasant surprise.
//    This routine truncates arguments outside the range.
//  Author:    John Burkardt
  if ( c <= -1.0E+00 )
  {
    return 180;
  } 
  else if ( 1.0E+00 <= c )
  {
    return 0.0;
  }
  else
  { 
  // Output of the following functions is in degrees 
  //  The angle is computed using the ACOS function, and so 
  //  lies between 0 and PI.  But if one of the lines is degenerate, 
  //  the angle is returned as 0.0. so that is why ... 
    return (acos ( c ))*180/PI;
  }
}

void misGraphics3D::setColor(COLOR c, double a){
  switch (c){
    case BLACK:
         color[0]=0.0;
         color[1]=0.0;
         color[2]=0.0;
         color[3]=a;
      break;
   case RED:
         color[0]=1.0;
         color[1]=0.0;
         color[2]=0.0;
         color[3]=a;
      break;
    case GREEN:
         color[0]=0.0;
         color[1]=1.0;
         color[2]=0.0;
         color[3]=a;
      break;
    case YELLOW:
         color[0]=1.0;
         color[1]=1.0;
         color[2]=0.0;
         color[3]=a;
      break;
    case CYAN:
         color[0]=0.0;
         color[1]=1.0;
         color[2]=1.0;
         color[3]=a;
      break;
    case  MAGENTA:
         color[0]=1.0;
         color[1]=0.0;
         color[2]=1.0;
         color[3]=a;
      break;  
      case WHITE:
         color[0]=1.0;
         color[1]=1.0;
         color[2]=1.0;
         color[3]=a;
      break;
        case GRAY:
         color[0]=0.75;
         color[1]=0.75;
         color[2]=0.75;
         color[3]=a;
      break;
        case AQUA:
         color[0]=0.0;
         color[1]=1.0;
         color[2]=1.0;
         color[3]=a;
      break;
        case FUCHSIA:
         color[0]=1.0;
         color[1]=0.0;
         color[2]=1.0;
         color[3]=a;
      break;
        case LIME:
         color[0]=0.25;
         color[1]=0.8;
         color[2]=0.25;
         color[3]=a;
      break;
        case MAROON:
         color[0]=0.5;
         color[1]=0.0;
         color[2]=0.0;
         color[3]=a;
      break;
        case TEAL:
         color[0]=0.0;
         color[1]=0.5;
         color[2]=0.5;
         color[3]=a;
    
       break;
        case SILVER:
         color[0]=0.75;
         color[1]=0.75;
         color[2]=0.75;
         color[3]=a;
         break;
        case  PURPLE:
         color[0]=0.5;
         color[1]=0.0;
         color[2]=0.5;
         color[3]=a;
   
       break;
        case  OLIVE:
         color[0]=0.5;
         color[1]=0.5;
         color[2]=0.0;
         color[3]=a;
      break;
        case NAVY:
         color[0]=0.0;
         color[1]=0.0;
         color[2]=0.5;
         color[3]=a;
      break;
     case ORANGE:
         color[0]=1.0;
         color[1]=0.6;
         color[2]=0.0;
         color[3]=a;
      break;
     case PINK:
         color[0]=1.0;
         color[1]=0.70;
         color[2]=0.8;
         color[3]=a;
      break;
	 case BLUE:
         color[0]=0.0;
         color[1]=0.0;
         color[2]=1.0;
         color[3]=a;
      break;
 }
}

void misGraphics3D::initLight(void){
  GLfloat light_ambient[] = {0.17, 0.3, 0.3, 1.0};
	GLfloat light_diffuse[] = {0.9, 0.8, 0.6, 1.0};
	GLfloat light_specular[] = {1.0, 1.0, 1.0, 1.0};
	/* light_position is NOT default value */
	GLfloat light_position[] = {-1.0, 1.0, 1.0, 0.0};

	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_LINE_SMOOTH);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);
	//glEnable(GL_CULL_FACE);
	glEnable(GL_COLOR_MATERIAL);
	glEnable(GL_BLEND);
	glShadeModel(GL_SMOOTH);
	glDepthFunc(GL_LESS);
	//glDepthFunc(GL_EQUAL);
  glEnable(GL_ALPHA_TEST);
  //glBlendFunc(GL_SRC_ALPHA_SATURATE, GL_ONE);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	//glBlendFunc(GL_ONE, GL_ONE);
	//glColorMaterial(GL_FRONT_AND_BACK,GL_SPECULAR );
	glColorMaterial(GL_FRONT_AND_BACK, GL_AMBIENT_AND_DIFFUSE);
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE );
	//Parameters are :
	//face : GL_FRONT_AND_BACK, GL_FRONT or GL_BACK
	//mode : GL_POINT, GL_LINE or GL_FILL
	//glEnable(GL_FOG);


  }



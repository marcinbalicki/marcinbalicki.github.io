//#include <iostream.h>
#include <stdlib.h>

#include "misSTL.h"

using namespace std;

misSTL::misSTL( void )
{
  fileName = "stlfile.stl"; //default file
  //	fileName="bone1d200smooth.stl";
  scale = 1.0f;
  idList = -1;
  UnitL = 1; // 0-mm, 1-inch
  lx = 0; ly = 0; lz = 0; hx = 0; hy = 0; hz = 0;
  axisUnits[0] = 25.4f;
  axisUnits[1] = 1.0f;
  pointModelList=-1; 
  stlModelList=-1;
}

misSTL::~misSTL( void )
{

}

bool misSTL::import( string file )
{
  //need to remove the reading of every element.

  this->fileName = file;
  FILE * m_FilePointer;
  // Here we open the desired file for read only and return the file pointer
  m_FilePointer = fopen( fileName.c_str(), "r" );

  // Check to make sure we have a valid file pointer
  if ( m_FilePointer==NULL )
  {
    // Create an error message for the attempted file
    cout << "Unable to find or open the file: " << fileName << endl;
    return false;
  }
  rewind( m_FilePointer );
  string str;
  stlVector.clear();
  //	double fsize;
  bool once = true;
  float x = 0.0, y = 0.0, z = 0.0;
  misFacet tempFacet;
  int pass = 0;
  char strWord[255] =
  {
    0
  };
  char gar[255] =
  {
    0
  }; //garbage variable.
 
  // Go through the file until we reach the end
  while ( !feof( m_FilePointer ) )
  {
    // Read in a word to check it against tags
    fscanf( m_FilePointer, "%s", & strWord );
    //if it is equal to facet
    if ( !strcmp( strWord, "facet" ) )
    {
      pass = 0;
      //extract the 4 words left on the line: "normal" x y z
      fscanf( m_FilePointer, "%s %e %e %e", & gar, & x, & y, & z );
      tempFacet.clear(); //clear the temporary variable
      //save for this facet
      tempFacet.normal.x = x;
      tempFacet.normal.y = y;
      tempFacet.normal.z = z;
    }
    //see if the word is the vertex.
    else if ( !strcmp( strWord, "vertex" ) )
    {
      //get the 3 exponential notation
      fscanf( m_FilePointer, "%e %e %e", & x, & y, & z );

      x *= ( scale * axisUnits[UnitL] );
      y *= ( scale * axisUnits[UnitL] );
      z *= ( scale * axisUnits[UnitL] );
      tempFacet.vertex[pass].x = x;
      tempFacet.vertex[pass].y = y;
      tempFacet.vertex[pass].z = z;

      pass++;
      if ( pass == 3 )
        stlVector.push_back( tempFacet );
      //insert my bounding box extraction code here.
      //find the largest x,y,z
      //find the smallest x,y,z
      //first time values need to be set here

      if ( once )
      {
        lx = x;
        hx = x;
        ly = y;
        hy = y;
        lz = z;
        hz = z;
        once = false;
      }

      if ( lx > x ) lx = x;
      if ( hx < x ) hx = x;
      if ( ly > y ) ly = y;
      if ( hy < y ) hy = y;
      if ( lz > z ) lz = z;
      if ( hz < z ) hz = z;

    }
    // Go to the next line
    else
      fgets( strWord, 100, m_FilePointer );
  }

  // Close the file that we opened
  fclose( m_FilePointer );
  createStlList();
 // moveToOrigin();
  cout << endl;
  cout <<"\""<< fileName<<"\""<<" read successfully."<<endl;
  cout << "Bounding Box:" << endl;
  cout << "Lower: x=" << lx << " y=" << ly << " z=" << lz << endl;
  cout << "Higher: x=" << hx << " y=" << hy << " z=" << hz << endl;
  cout << "Number of Facets: " << (int)stlVector.size() << endl<<endl;

  //	tryPerspective();
  return true;
}

//this averags each facet to a point and creates a new vector.
void misSTL::createPointVector( void )
{

  misPoint v;
  if ( !stlVector.empty() )
  {
    for ( vectStlIter vi = stlVector.begin(); vi != stlVector.end(); ++vi )
    {
      v.x = ( vi->vertex[0].x + vi->vertex[1].x + vi->vertex[2].x ) / 3;
      v.y = ( vi->vertex[0].y + vi->vertex[1].y + vi->vertex[2].y ) / 3;
      v.z = ( vi->vertex[0].z + vi->vertex[1].z + vi->vertex[2].z ) / 3;
      stlPtVector.push_back( v );
    }
  }
}

int misSTL::createStlList( void )
{

  idList = glGenLists( 1 );
  glNewList( idList, GL_COMPILE );
  glBegin( GL_TRIANGLES );
  //cylce through all the facets using vector iterator
  for ( vectStlIter vi = stlVector.begin(); vi != stlVector.end(); ++vi )
  {
    //iterator is like a pointer.
    glNormal3f( vi->normal.x, vi->normal.y, vi->normal.z );
    glVertex3f( vi->vertex[0].x, vi->vertex[0].y, vi->vertex[0].z );
    glVertex3f( vi->vertex[1].x, vi->vertex[1].y, vi->vertex[1].z );
    glVertex3f( vi->vertex[2].x, vi->vertex[2].y, vi->vertex[2].z );
  }
  glEnd();
  glEndList();
  stlModelList = idList;
  return idList;
}

int misSTL::createPointList( void )
{
  idList = glGenLists( 1 );
  glNewList( idList, GL_COMPILE );
  glPointSize( 2 ); //size of side of square in pixels
  glBegin( GL_POINTS );
  //cylce through all the facets using vector iterator
  for ( vectPtIter vi = stlPtVector.begin(); vi != stlPtVector.end(); ++vi )
  {
    //iterator is like a pointer.
    glVertex3f( vi->x, vi->y, vi->z );
  }
  glEnd();
  glEndList();
  pointModelList = idList;
  return idList;
}

void misSTL::setScale( float s )
{
  scale = s;
}

void misSTL::draw(LIST l)
  {
  switch (l){
  case POLYGON: 
   {
      //glColor();
      if (stlModelList != -1 )
          glCallList( stlModelList );
      else
          cout << "No call list created" << endl;
      break; 
   }

  case POINT:
   {
     //glColor();
      if (pointModelList != -1 )
         glCallList(pointModelList);
      else
          cout << "No call list created" << endl;
      break;
   }
 }
}

// draws bounding box
void misSTL::drawBox( void )
{
  glColor();
  glPushMatrix();
  //glRotatef(90, 0.0, 1.0, 0.0);
  //glRotatef(90, 1.0, 0.0, 0.0);
  //glTranslatef(-lx, -ly, -lz);
  //glTranslatef(-80.0, 80.0, 0.0);
  glLineWidth( 2 );
  //glLineStipple(2,0xAAAA);
  //glEnable(GL_LINE_STIPPLE);
  glBegin( GL_LINE_STRIP );
  glVertex3f( lx, ly, lz );
  glVertex3f( hx, ly, lz );
  glVertex3f( hx, hy, lz );
  glVertex3f( lx, hy, lz );
  glVertex3f( lx, ly, lz );
  glVertex3f( lx, ly, hz );
  glVertex3f( lx, hy, hz );
  glVertex3f( hx, hy, hz );
  glVertex3f( hx, ly, hz );
  glVertex3f( lx, ly, hz );
  glEnd();
  glBegin( GL_LINES );
  glVertex3f( lx, hy, lz );
  glVertex3f( lx, hy, hz );
  glEnd();

  glBegin( GL_LINES );
  glVertex3f( hx, hy, lz );
  glVertex3f( hx, hy, hz );
  glEnd();
  glBegin( GL_LINES );
  glVertex3f( hx, ly, lz );
  glVertex3f( hx, ly, hz );
  glEnd();
  glPopMatrix();

}

void misSTL::moveToOrigin( void )
{
  for ( vectStlIter vi = stlVector.begin(); vi != stlVector.end(); ++vi )
  {
    //iterator is like a pointer.
    vi->vertex[0].x = vi->vertex[0].x - lx;
    vi->vertex[0].y = vi->vertex[0].y - ly;
    vi->vertex[0].z = vi->vertex[0].z - lz;
    vi->vertex[1].x = vi->vertex[1].x - lx;
    vi->vertex[1].y = vi->vertex[1].y - ly;
    vi->vertex[1].z = vi->vertex[1].z - lz;
    vi->vertex[2].x = vi->vertex[2].x - lx;
    vi->vertex[2].y = vi->vertex[2].y - ly;
    vi->vertex[2].z = vi->vertex[2].z - lz;

  }
  //reset the bounding box.
  hx -= lx;
  hy -= ly;
  hz -= lz;
  lx = 0.0;
  ly = 0.0;
  lz = 0.0;

}


//trying something

//
void misSTL::tryPerspective( void )
{
  double OneOverZ = 0.0;
  //this is the field of view scale.
  //40-150
  double XSCALE = 140.0;
  double YSCALE = 140.0;
  //what?
  double XCenter = 0.0;
  double YCenter = 0.0;

  //for (vectPtIter vi=stlPtVector.begin(); vi!=stlPtVector.end(); ++vi)
  //		{
  //		OneOverZ = 1/vi->z;
  //		vi->x= vi->x * XSCALE * OneOverZ + XCenter;
  //		vi->y= vi->y * YSCALE * OneOverZ + YCenter;
  //		//iterator is like a pointer.
  //
  //	 }
  for ( vectStlIter vi = stlVector.begin(); vi != stlVector.end(); ++vi )
  {
    //iterator is like a pointer.
    //glNormal3f(vi->normal[0], vi->normal[1],vi->normal[2]);
    OneOverZ = 1 / vi->vertex[0].z;
    vi->vertex[0].x = vi->vertex[0].x * XSCALE * OneOverZ + XCenter;
    vi->vertex[0].y = -vi->vertex[0].y * YSCALE * OneOverZ + YCenter;
    OneOverZ = 1 / vi->vertex[1].z;
    vi->vertex[1].x = vi->vertex[1].x * XSCALE * OneOverZ + XCenter;
    vi->vertex[1].y = -vi->vertex[1].y * YSCALE * OneOverZ + YCenter;
    OneOverZ = 1 / vi->vertex[2].z;
    vi->vertex[2].x = vi->vertex[2].x * XSCALE * OneOverZ + XCenter;
    vi->vertex[2].y = -vi->vertex[2].y * YSCALE * OneOverZ + YCenter;

  }
}

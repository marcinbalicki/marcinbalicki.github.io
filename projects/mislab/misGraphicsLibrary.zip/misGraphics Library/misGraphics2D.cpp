//---------------------------------------------------------------------------
// misGraphics2D.cpp
//---------------------------------------------------------------------------

#include "misGraphics2D.h"
#include "math.h"
#include <windows.h>		// Header File For Windows
#include <iomanip>
#include <sstream>
#include <fstream>

using namespace std;

bool misGraphics2D::initialized=false;
GLUquadricObj * misGraphics2D::QObj=NULL;

GLuint misGraphics2D::base10;
GLuint misGraphics2D::base12;
GLuint misGraphics2D::base14;
GLuint misGraphics2D::base16;
GLuint misGraphics2D::base18;
GLuint misGraphics2D::base20;
GLuint misGraphics2D::base22;
GLuint misGraphics2D::base24;
GLuint misGraphics2D::base26;
GLuint misGraphics2D::base28;
GLuint misGraphics2D::base32;
GLuint misGraphics2D::base36;
GLuint misGraphics2D::base48;
GLuint misGraphics2D::base60;
GLuint misGraphics2D::base72;
GLuint misGraphics2D::base100;

/* The most commonly used variant of the command to set RGBA colors
is glColor3f(GLfloat red, GLfloat green, GLfloat blue)
where red, green, and blue are values between 0.0 and 1.0, inclusive. The
value 0.0 corresponds to the minimum amount of that color while 1.0
corresponds to the maximum amount of that color. Commonly Used RGB Colors */
// glColor3f(0.0, 0.0, 0.0); //Black
// glColor3f(1.0, 0.0, 0.0); //Red
// glColor3f(0.0, 1.0, 0.0); //Green
// glColor3f(0.0, 0.0, 1.0); //Blue
// glColor3f(1.0, 1.0, 0.0); //Yellow
// glColor3f(0.0, 1.0, 1.0); //Cyan
// glColor3f(1.0, 0.0, 1.0); //Magenta
// glColor3f(1.0, 1.0, 1.0); //White

double misGraphics2D::PI=3.141592653589793;
double misGraphics2D::PI_DIV_180=misGraphics2D::PI/180.0;

misGraphics2D::misGraphics2D(void) {
  setColor();
}

misGraphics2D::~misGraphics2D(void) { 
}

void misGraphics2D::getScreenDims(void) {
  //get dims and set them
  w = glutGet(GLUT_WINDOW_WIDTH);
  h = glutGet(GLUT_WINDOW_HEIGHT);
}

// Use glVertex2f() to specify 2d coords. After you've done your 2d work you
// can return to previous state with Exit2dMode().
// The projection matrix is mapped to the pixels,
// left=top=0 and right=width and bottom=height of the screen.
// That way you can say glVertex(5,5) maps to the pixel 5,5 of the screen.

void misGraphics2D::enter2dMode(void) {

  float z = 0.0;
  float ww = 1.0;
  //this is required
  getScreenDims();

  glMatrixMode(GL_PROJECTION);
  glPushMatrix();
  // There is a slight discrepency in the arguments between the ortho and the
  // viewport methods.The ortho method takes left, right,bottom and top parameters
  // while the viewport method takes bottomX, bottomY, width,and height parameters.
  // A bit confusing but easy enough to use.

  glLoadIdentity();
  double wsize   = -w / 2.0; //initial 1/2 view size.in mm
  double _top    = wsize;
  double _bottom = -wsize;
  double _left   = -((double)h / (double)w) * wsize;
  double _right  = -_left;

  gluOrtho2D(_top, _bottom, _left, _right);
  /* Push current matrix mode and viewport attributes. */
  glPushAttrib(GL_TRANSFORM_BIT | GL_VIEWPORT_BIT | GL_COLOR_BUFFER_BIT);

  glMatrixMode(GL_MODELVIEW);
  glViewport(0, 0, w, h);
  glPushMatrix();
  glLoadIdentity();
  //if I make this 0, 1 the 2d stuff will be drawn as the backgroung
  //very cool.
  glDepthRange(z, z);
  glTranslatef(-w / 2.0, -h / 2.0, 0.0);
  glRasterPos4f(-w / 2.0 + 1, -h / 2.0, 0.0, ww);
  /* Setup projection parameters. */
  //set the light used by the colors.
  glEnable(GL_LINE_SMOOTH);
  glDisable(GL_LIGHTING);
  glDisable(GL_BLEND);
  //glEnable(GL_BLEND);
  glDisable(GL_DEPTH_TEST);

  //lighting makes the text disapear for some reason.
  //
 
}

void misGraphics2D::exit2dMode(void) {
  /* Restore matrices, viewport and matrix mode. */

  glPopMatrix();
  glMatrixMode(GL_PROJECTION);
  glPopMatrix();
  glPopAttrib();
  glMatrixMode(GL_MODELVIEW);
  glEnable(GL_LIGHTING);
  glEnable(GL_BLEND);
  glEnable(GL_DEPTH_TEST);

}

//text requires glRasterPos2f(400, 500);
//for movement.
void misGraphics2D::text(int size, string s) {

  glPushAttrib(GL_LIST_BIT); // Pushes The Display List Bits
  switch (size) {

    case 10:
      glListBase(base10 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
    case 12:
      glListBase(base12 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
    case 14:
      glListBase(base14 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
    case 16:
      glListBase(base16 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
    case 18:
      glListBase(base18 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
    case 20:
      glListBase(base20 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
	case 22:
      glListBase(base22 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
    case 24:
      glListBase(base24 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
    case 26:
      glListBase(base26 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
	case 28:
      glListBase(base28 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
	case 32:
      glListBase(base32 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
    case 36:
      glListBase(base36 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
    case 48:
      glListBase(base48 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
	case 60:
      glListBase(base60 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
    case 72:
      glListBase(base72 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
    case 100:
      glListBase(base100 - 32); // Sets The Base Character to 32
      glCallLists((GLsizei)strlen(s.c_str()), GL_UNSIGNED_BYTE, s.c_str()); // Draws The Display List Text
      break;
    default:
		cout<<"ERROR: misGraphics2D >> font size does not exist"<<endl;
		return;
  }
  glPopAttrib(); // Pops The Display List Bits
}

void misGraphics2D::buildFont(void) // Build Our Bitmap Font
{
  HFONT font; // Windows Font ID
  HFONT oldfont; // Used For Good House Keeping
  base10 = glGenLists(96); // Storage For 96 Characters
  base12 = glGenLists(96);
  base14 = glGenLists(96);
  base16 = glGenLists(96);
  base18 = glGenLists(96);
  base20 = glGenLists(96);
  base22 = glGenLists(96); // Storage For 96 Characters
  base24 = glGenLists(96); // Storage For 96 Characters
  base26 = glGenLists(96);
  base28 = glGenLists(96);
  base32 = glGenLists(96);
  base36 = glGenLists(96);
  base48 = glGenLists(96);
  base60 = glGenLists(96);
  base72 = glGenLists(96);
  base100 = glGenLists(96);

  
  //10
  font = CreateFont(-10, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base10); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font
  
  //12
  font = CreateFont(-12, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base12); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font

   //14
  font = CreateFont(-14, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base14); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font

   //16
  font = CreateFont(-16, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base16); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font

   //18
  font = CreateFont(-18, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base18); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font

   //20
  font = CreateFont(-20, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base20); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font


  //22
  font = CreateFont(-22, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base22); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font

  //24
  font = CreateFont(-24, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base24); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font

  //26
  font = CreateFont(-26, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base26); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font

  //28
  font = CreateFont(-28, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base28); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font

  //32
  font = CreateFont(-32, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base32); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font

   //36
  font = CreateFont(-36, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base36); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font

  //48
  font = CreateFont(-48, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base48); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font

  //60
  font = CreateFont(-60, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base60); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font

  //72
  font = CreateFont(-72, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base72); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font
  
  //100
  font = CreateFont(-100, // Height Of Font
  0, // Width Of Font
  0, // Angle Of Escapement
  0, // Orientation Angle
  FW_BOLD, // Font Weight
  FALSE, // Italic
  FALSE, // Underline
  FALSE, // Strikeout
  ANSI_CHARSET, // Character Set Identifier
  OUT_TT_PRECIS, // Output Precision
  CLIP_DEFAULT_PRECIS, // Clipping Precision
  ANTIALIASED_QUALITY, // Output Quality
  FF_DONTCARE | DEFAULT_PITCH, // Family And Pitch
  "Arial"); // Font Name
  oldfont = (HFONT)SelectObject(wglGetCurrentDC(), font); // Selects The Font We Want
  wglUseFontBitmaps(wglGetCurrentDC(), 32, 96, base100); // Builds 96 Characters
  // Starting At Character 32
  SelectObject(wglGetCurrentDC(), oldfont); // Selects The Font We Want
  DeleteObject(font); // Delete The Font

}
void misGraphics2D::demo2DText(void){

	draw2DText(100,120,10,"10");
	draw2DText(100,140,12,"12");
	draw2DText(100,160,14,"14");
	draw2DText(100,180,16,"16");
	draw2DText(100,200,18,"18");
	draw2DText(100,220,20,"20");
	draw2DText(100,250,22,"22");
	draw2DText(100,280,24,"24");
	draw2DText(100,310,26,"26");
	draw2DText(100,340,28,"28");
	draw2DText(100,390,32,"32");
	draw2DText(100,440,36,"36");
	draw2DText(100,490,48,"48");
	draw2DText(100,540,60,"60");
	draw2DText(100,600,72,"72");
	draw2DText(100,700,100,"100");
}

void misGraphics2D::killFont(void) // Delete The Font List
{
  glDeleteLists(base10, 96); // Delete All 96 Characters
  glDeleteLists(base12, 96); // Delete All 96 Characters
  glDeleteLists(base14, 96); // Delete All 96 Characters
  glDeleteLists(base16, 96); // Delete All 96 Characters
  glDeleteLists(base18, 96); // Delete All 96 Characters
  glDeleteLists(base20, 96); // Delete All 96 Characters
  glDeleteLists(base22, 96); // Delete All 96 Characters
  glDeleteLists(base24, 96); // Delete All 96 Characters
  glDeleteLists(base26, 96); // Delete All 96 Characters
  glDeleteLists(base28, 96); // Delete All 96 Characters
  glDeleteLists(base32, 96); // Delete All 96 Characters
  glDeleteLists(base36, 96); // Delete All 96 Characters
  glDeleteLists(base48, 96); // Delete All 96 Characters
  glDeleteLists(base60, 96); // Delete All 96 Characters
  glDeleteLists(base72, 96); // Delete All 96 Characters
  glDeleteLists(base100, 96); // Delete All 96 Characters

}


string misGraphics2D::convToString(double d) {
  ///internal stream function used in toString()
  ostringstream oss;
  oss << setiosflags(ios_base::showpoint) << setiosflags(ios_base::right);
  oss << setiosflags(ios_base::fixed) << setprecision(1) << setw(4) <<
       setiosflags(ios_base::showpos) << d; // insert double into stream
  return oss.str();
}

string misGraphics2D::convToString(int i) {
  ///internal stream function used in toString()
  ostringstream oss;
  oss << setiosflags(ios_base::right);
  oss << setiosflags(ios_base::fixed) << setprecision(0) << setw(4) <<
       setiosflags(ios_base::showpos) << i; // insert double into stream
  return oss.str();
  }

string misGraphics2D::convToString2(double d) {
  ///internal stream function used in toString()
  ostringstream oss;
  oss << setiosflags(ios_base::right) << setiosflags(ios_base::showpos);
  oss << setw(4) << d; // insert double into stream
  return oss.str();
}
string misGraphics2D::convToString3(double d) {
  ///internal stream function used in toString()
  ostringstream oss;
  oss << setiosflags(ios_base::left) << d; // insert double into stream
  return oss.str();
}
string misGraphics2D::convToString4(double d) {
  ///internal stream function used in toString()
  ostringstream oss;
  oss << setiosflags(ios_base::left)<<  setiosflags(ios_base::fixed)<< setw(7) << setprecision(3) << d; // insert double into stream
  return oss.str();
}
void misGraphics2D::draw2Dcircle(int x, int y,double radius, double thickness, int segments) {
    glColor();
	enter2dMode();
    glPushMatrix();
		 glTranslatef(x,getScreenMaxY()-y,0);
		gluDisk(QObj,radius - thickness,radius,segments,8 );
	glPopMatrix();
    exit2dMode();
}

void misGraphics2D::draw2DcircleSolid(int x, int y, double radius, int segments) {
	glColor();
	enter2dMode();
    glPushMatrix();
		glTranslatef(x,getScreenMaxY()-y,0);
		gluDisk(QObj,0.0,radius,segments,8 );
    glPopMatrix();
    exit2dMode();
}

void misGraphics2D::init(void){
    if (!initialized)
      buildFont();
      QObj = gluNewQuadric();
      initialized=true; 
      cout<<"INITIALIZED BMP FONTS"<<endl;
}
void misGraphics2D::destroy(void){
      if (initialized){
      gluDeleteQuadric(QObj);
	  killFont();
      initialized=false; 
 }
}

void misGraphics2D::draw2DText(int x, int y,  int size, string s){    
      enter2dMode(); 
      glColor();
	  setPosition2D( x, y);
      text(size, s.c_str()); 
      exit2dMode();
  }

void misGraphics2D::setPosition2D(int x, int y){
	glRasterPos2f(x,getScreenMaxY()-y);
}

int misGraphics2D::getScreenMaxX(void){
      //return glutGet(GLUT_WINDOW_WIDTH);
	return w;
}

int misGraphics2D::getScreenMaxY(void){ 
	 //return glutGet(GLUT_WINDOW_HEIGHT);
	return h;
}

void misGraphics2D::glColor(void){
   glColor4f(color[0],color[1],color[2], color[3]);
  }

void misGraphics2D::draw2DAxes(int x, int y, double length, int width){
  //left knee:
  //draw lines
  //length of 1/2 axis
  glColor();
  glLineWidth(width);
  enter2dMode();
  glPushMatrix();
  glTranslatef(x,getScreenMaxY()-y,0);
  int la = length;
  glBegin(GL_LINES);
	glVertex2f(-la, 0.0f);
	glVertex2f(la, 0.0f);
  glEnd();
  glBegin(GL_LINES);
	 glVertex2f(0.0, -la);
	 glVertex2f(0.0f, la);
  glEnd();
  glPopMatrix();
  exit2dMode();

}
void misGraphics2D::draw2DRectangle(int x1,int y1,int x2,int y2){
  glColor();
  enter2dMode();
  glBegin(GL_POLYGON);
      glVertex2f (x1, getScreenMaxY()-y1);
      glVertex2f (x2, getScreenMaxY()-y1);
      glVertex2f (x2, getScreenMaxY()-y2);
      glVertex2f (x1, getScreenMaxY()-y2);
  glEnd();
  exit2dMode();
}


 ///draw a point pixel
void misGraphics2D::draw2DPoint(double x,double y, int size){
  glColor();
  enter2dMode();
  glPointSize(size);
   glBegin (GL_POINTS);
    glVertex3d(x,getScreenMaxY()-y,0);
   glEnd();
  exit2dMode();
}
void misGraphics2D::draw2DLine(int x1,int y1,int x2,int y2,int width){
  glColor();
  enter2dMode();
  glLineWidth(width);
  glBegin(GL_LINES);
	glVertex2i(x1, getScreenMaxY()-y1);
	glVertex2i(x2, getScreenMaxY()-y2);
  glEnd();
  exit2dMode();
}


void misGraphics2D::setColor(COLOR c, double a){
  switch (c){
    case BLACK:
         color[0]=0.0;
         color[1]=0.0;
         color[2]=0.0;
         color[3]=a;
      break;
   case RED:
         color[0]=1.0;
         color[1]=0.0;
         color[2]=0.0;
         color[3]=a;
      break;
    case GREEN:
         color[0]=0.0;
         color[1]=1.0;
         color[2]=0.0;
         color[3]=a;
      break;
    case YELLOW:
         color[0]=1.0;
         color[1]=1.0;
         color[2]=0.0;
         color[3]=a;
      break;
    case CYAN:
         color[0]=0.0;
         color[1]=1.0;
         color[2]=1.0;
         color[3]=a;
      break;
    case  MAGENTA:
         color[0]=1.0;
         color[1]=0.0;
         color[2]=1.0;
         color[3]=a;
      break;  
      case WHITE:
         color[0]=1.0;
         color[1]=1.0;
         color[2]=1.0;
         color[3]=a;
      break;
        case GRAY:
         color[0]=0.75;
         color[1]=0.75;
         color[2]=0.75;
         color[3]=a;
      break;
        case AQUA:
         color[0]=0.0;
         color[1]=1.0;
         color[2]=1.0;
         color[3]=a;
      break;
        case FUCHSIA:
         color[0]=1.0;
         color[1]=0.0;
         color[2]=1.0;
         color[3]=a;
      break;
        case LIME:
         color[0]=0.25;
         color[1]=0.8;
         color[2]=0.25;
         color[3]=a;
      break;
        case MAROON:
         color[0]=0.5;
         color[1]=0.0;
         color[2]=0.0;
         color[3]=a;
      break;
        case TEAL:
         color[0]=0.0;
         color[1]=0.5;
         color[2]=0.5;
         color[3]=a;
    
       break;
        case SILVER:
         color[0]=0.75;
         color[1]=0.75;
         color[2]=0.75;
         color[3]=a;
         break;
        case  PURPLE:
         color[0]=0.5;
         color[1]=0.0;
         color[2]=0.5;
         color[3]=a;
   
       break;
        case  OLIVE:
         color[0]=0.5;
         color[1]=0.5;
         color[2]=0.0;
         color[3]=a;
      break;
        case NAVY:
         color[0]=0.0;
         color[1]=0.0;
         color[2]=0.5;
         color[3]=a;
      break;
     case ORANGE:
         color[0]=1.0;
         color[1]=0.6;
         color[2]=0.0;
         color[3]=a;
      break;
     case PINK:
         color[0]=1.0;
         color[1]=0.70;
         color[2]=0.8;
         color[3]=a;
      break;
	 case BLUE:
         color[0]=0.0;
         color[1]=0.0;
         color[2]=1.0;
         color[3]=a;
      break;
 }
}
//void misGraphics2D::draw(int x, int y){
  /* 
  enter2dMode();
  string str; 
  getScreenDims();
  glDisable(GL_LIGHTING);
//  int guidanceWidthScale=w-backgroundImg.getScaledWidthFromHeight(h);
  //int guidanceWidthScale=(image5.getW()/(float)logoImgWide.getW())*w;
  //cout<<" w sscale " <<guidanceWidthScale<<endl;

  //glRasterPos2f(x, y);
  switch (current){

   case 1:   {
   
     glDisable(GL_BLEND);
     
     int wd=((float)1110/(float)1321)*guidanceWidthScale;
     
     int st;
     if (w > 1600)
            st=3;
     else if (w > 1000)
            st=2;
     else if (w > 800)
            st=1;
     else st=0;
  
     glColor4f(0.0, 0.0, 0.0); 
     glRasterPos2f(wd, h-((float)205/(float)328)*image1.getScaledHeightFromWidth(guidanceWidthScale));
     str = convToString(frontalAngle);
     text(st, str.c_str());
     glRasterPos2f(wd, h-((float)148/(float)328)*image1.getScaledHeightFromWidth(guidanceWidthScale));
     str = convToString(sagitalAngle);
     text(st, str.c_str());
     glRasterPos2f(wd, h-((float)92/(float)328)*image1.getScaledHeightFromWidth(guidanceWidthScale));
     str = convToString(distance);
     text(st, str.c_str());
     glEnable(GL_BLEND);
   
     
     glRasterPos2f(0, h);
     image1.drawWithNewWidth(guidanceWidthScale);
     glRasterPos2f(0, logoImg.getScaledHeightFromWidth(guidanceWidthScale)+1);
     logoImg.drawWithNewWidth(guidanceWidthScale);
   
     break;
     }
   case 2: 
     {
     glDisable(GL_BLEND);

     int wd=((float)1110/(float)1321)*guidanceWidthScale;
     
     int st;
     if (w > 1600)
            st=3;
     else if (w > 1000)
            st=2;
     else if (w > 800)
            st=1;
     else st=0;
 
     glColor4f(0.0, 0.0, 0.0); 
     glRasterPos2f(wd, h-((float)205/(float)328)*image2.getScaledHeightFromWidth(guidanceWidthScale));
     str = convToString(frontalAngle);
     text(st, str.c_str());
     glRasterPos2f(wd, h-((float)148/(float)328)*image2.getScaledHeightFromWidth(guidanceWidthScale));
     str = convToString(sagitalAngle);
     text(st, str.c_str());
     glRasterPos2f(wd, h-((float)92/(float)328)*image2.getScaledHeightFromWidth(guidanceWidthScale));
     str = convToString(distance);
     text(st, str.c_str());
     glEnable(GL_BLEND);
   
     glRasterPos2f(0, h);
     image2.drawWithNewWidth(guidanceWidthScale);
     glRasterPos2f(0, logoImg.getScaledHeightFromWidth(guidanceWidthScale)+1);
     logoImg.drawWithNewWidth(guidanceWidthScale);

     break;
     }
   case 3: 
	 {
     glDisable(GL_BLEND);
     
     int wd=((float)1110/(float)1321)*guidanceWidthScale;
     
     int st;
     if (w > 1600)
            st=3;
     else if (w > 1000)
            st=2;
     else if (w > 800)
            st=1;
     else st=0;
  
     glColor4f(0.0, 0.0, 0.0); 
     glRasterPos2f(wd, h-((float)205/(float)328)*image3.getScaledHeightFromWidth(guidanceWidthScale));
     str = convToString(frontalAngle);
     text(st, str.c_str());
     glRasterPos2f(wd, h-((float)148/(float)328)*image3.getScaledHeightFromWidth(guidanceWidthScale));
     str = convToString(sagitalAngle);
     text(st, str.c_str());
     glRasterPos2f(wd, h-((float)92/(float)328)*image3.getScaledHeightFromWidth(guidanceWidthScale));
     str = convToString(distance);
     text(st, str.c_str());
     glEnable(GL_BLEND);
   
     
     glRasterPos2f(0, h);
     image3.drawWithNewWidth(guidanceWidthScale);
     glRasterPos2f(0, logoImg.getScaledHeightFromWidth(guidanceWidthScale)+1);
     logoImg.drawWithNewWidth(guidanceWidthScale);
   
     break;
	 }
   case 4: 
     {
     glDisable(GL_BLEND);

     int wd=((float)1110/(float)1321)*guidanceWidthScale;
     
     int st;
     if (w > 1600)
            st=3;
     else if (w > 1000)
            st=2;
     else if (w > 800)
            st=1;
     else st=0;
 
     glColor4f(0.0, 0.0, 0.0); 
     glRasterPos2f(wd, h-((float)205/(float)328)*image4.getScaledHeightFromWidth(guidanceWidthScale));
     str = convToString(frontalAngle);
     text(st, str.c_str());
     glRasterPos2f(wd, h-((float)148/(float)328)*image4.getScaledHeightFromWidth(guidanceWidthScale));
     str = convToString(sagitalAngle);
     text(st, str.c_str());
     glRasterPos2f(wd, h-((float)92/(float)328)*image4.getScaledHeightFromWidth(guidanceWidthScale));
     str = convToString(distance);
     text(st, str.c_str());
     glEnable(GL_BLEND);
   
     glRasterPos2f(0, h);
     image4.drawWithNewWidth(guidanceWidthScale);
     glRasterPos2f(0, logoImg.getScaledHeightFromWidth(guidanceWidthScale)+1);
     logoImg.drawWithNewWidth(guidanceWidthScale);

     break;
     }
   case 5: 
	   //resect
     glRasterPos2f(0, h);
     image5.drawWithNewWidth(w);
     glRasterPos2f(0, logoImgWide.getScaledHeightFromWidth(w)+1);
     logoImgWide.drawWithNewWidth(w);
     break;
   case 6: 
	   //jig analysis
     glRasterPos2f(0, h);
     image6.drawWithNewWidth(w);
     glRasterPos2f(0, logoImgWide.getScaledHeightFromWidth(w)+1);
     logoImgWide.drawWithNewWidth(w);
     break;
   case 7: 
	   //plate analysis
     glRasterPos2f(0, h);
     image7.drawWithNewWidth(w);
     glRasterPos2f(0, logoImgWide.getScaledHeightFromWidth(w)+1);
     logoImgWide.drawWithNewWidth(w);
     break;
   case 0:
   default:
     //draw nothing 
     glRasterPos2f(0, h);
     logoImgWide.drawWithNewWidth(w);
     glRasterPos2f(0, logoImgWide.getScaledHeightFromWidth(w)+1);
     logoImgWide.drawWithNewWidth(w);
     break;
    }
exit2dMode();
      */
//  }
